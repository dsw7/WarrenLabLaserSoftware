function [filename] = GetFileName(filename)
%UISAVE GUI Helper function for SAVE
%   
%   UISAVE with no args prompts for file name then saves all variables from
%   workspace.
%
%   UISAVE(VARIABLES) prompts for file name then saves variables listed in
%   VARIABLES, which may be a string or cell array of strings.
%
%   UISAVE(VARIABLES, FILENAME) uses the specified file name as the default
%   instead of "matlab.mat".
%
%   Examples:
%      Example 1:
%           h = 5;
%           uisave('h');
%
%      Example 2:
%           h = 365;
%           uisave('h', 'var1');
%
%   See also SAVE, LOAD
  
% Copyright 1984-2008 The MathWorks, Inc.
% $Revision: 1.12.4.11 $  $Date: 2011/09/08 23:36:27 $

whooutput = evalin('caller','who','');
%if isempty(whooutput) | (nargin > 0 & ...
%    (isempty(variables) | (iscell(variables) & cellfun('isempty',variables)))) %#ok<AND2,OR2>
%    errordlg(getString(message('MATLAB:uistring:filedialogs:DialogNoVariablesToSave')))
%    return;
%end

if length(whooutput) > 1
    % saving multiple variables to ascii is not very useful
    % the file will not re-load
    filters = {'*.csv'};
else
    filters = { '*.csv'};
end

if nargin < 1
    seed = 'TAdata.csv';
else
    seed = filename;
end


[fn,pn,filterindex] = uiputfile(filters, getString(message('MATLAB:uistring:filedialogs:SaveWorkspaceVariables')), seed);
if fn == 0
    return;
end
filename = strcat(pn,fn);
end

