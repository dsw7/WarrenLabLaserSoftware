function [ DK240 ] = OpenDK240Link(loc)
%OpenDK240Link opens communication with the DK240 Monochromator
%  input
%   loc = location of monochromator (i.e. 'COM3')
%  output
%   DK240 = device for use
%  
%  If location is input, function searches location for monochromator, if
%  no location is input, function searches all available serial ports for
%  monochromator.

%handles input argument
if nargin == 1
    %connecting
    DK240 = serial('COM1');
    try
        %opening communication
        fopen(DK240);
        %Executing monochromotar echo command
        fwrite(DK240, 27);
        %pausing to allow monochromator to process
        pause(.2)
        %retreiving echo
        response = fread(DK240, DK240.BytesAvailable);
    catch
        %if an error occured, connections are closed
        fclose(DK240);
        clear DK240;
        DK240 = 'device not found';
    end
%handles no input situation
else
    %serial locations to check
    COM ={'COM1','COM2','COM3','COM4','COM5','COM6','COM7','COM8'};
    %value for looping
    i = 1;
    %boolean for connection made
    linked = 0;
    %while loop executes while link has not been made and all ports have
    %not been checked
    while (linked == 0)&&(i<=length(COM))
        %boolean for location possible
        available = 1;
        try
            %retreiving location to check from array
            location = COM{i};
            %Connection being made
            DK240 = serial(location);
            %Opening communication
            fopen(DK240);
            %executing echo to monochromotar
            fwrite(DK240, 27);
            %pausing to allow instrument to respond
            pause(.2);
            %retreiving echo
            response = fread(DK240, DK240.BytesAvailable);
        catch
            %closing connection if monochromotar not present
            try
                fclose(DK240);
                clear DK240;
            catch
            end
            DK240 = 'fuck! device not found';
            available = 0;
        end
        %opening connection if device detected
        if available == 1;
            fwrite(DK240, 27);
            pause(.2)
            response = fread(DK240, DK240.BytesAvailable);
            %signifying link
            if response == 27
                linked = 1;
            else
                DK240 = 'device not found';
            end
        end
        i = i+1;
    end
end

