function varargout = QC9514gui(varargin)
% QC9514GUI MATLAB code for QC9514gui.fig
%      QC9514GUI, by itself, creates a new QC9514GUI or raises the existing
%      singleton*.
%
%      H = QC9514GUI returns the handle to a new QC9514GUI or the handle to
%      the existing singleton*.
%
%      QC9514GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in QC9514GUI.M with the given input arguments.
%
%      QC9514GUI('Property','Value',...) creates a new QC9514GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before QC9514gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to QC9514gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help QC9514gui

% Last Modified by GUIDE v2.5 10-Jul-2013 08:10:14

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @QC9514gui_OpeningFcn, ...
                   'gui_OutputFcn',  @QC9514gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before QC9514gui is made visible.
function QC9514gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to QC9514gui (see VARARGIN)

% Choose default command line output for QC9514gui
%creating pause timelength for all communication with instrument
global pausetime;
global deviceLocation;
pausetime = .1;
handles.output = hObject;

%opening communication to instrument
[device,deviceLocation] = OpenQC9514Link();
%setting pulse generator screen to automatically update
fprintf(device, ':display:mode on<cr><lf>');
pause(pausetime);
fscanf(device);
%setting pulse generator brightness to 2.
fprintf(device, ':display:brightness 2<cr><lf>');
pause(pausetime);
fscanf(device);
%closing communication with device
fclose(device);
clear device;

%updating all fields of display
ResetButton_Callback(hObject, eventdata, handles)
value = get(handles.NormalMode, 'Value');
if value == 1
    set(handles.NormalPanel, 'Visible', 'on');
else
    set(handles.NormalPanel, 'Visible', 'off');
end    
value = get(handles.SingleMode, 'Value');
if value == 1
    set(handles.SinglePanel, 'Visible', 'on');
else
    set(handles.SinglePanel, 'Visible', 'off');
end   
value = get(handles.BurstMode, 'Value');
if value == 1
    set(handles.BurstPanel, 'Visible', 'on');
else
    set(handles.BurstPanel, 'Visible', 'off');
end  
value = get(handles.DutyMode, 'Value');
if value == 1
    set(handles.DutyPanel, 'Visible', 'on');
else
    set(handles.DutyPanel, 'Visible', 'off');
end   
 

% Update handles structure
%guidata(hObject, handles);

% UIWAIT makes QC9514gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = QC9514gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in UpdateButton.
function UpdateButton_Callback(hObject, eventdata, handles)
% hObject    handle to UpdateButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global deviceLocation;
device = OpenQC9514Link(deviceLocation);

%Updating On/Off status of Channels
value = get(handles.AOnOff, 'Value');
if value == 1;
    fprintf(device, ':pulse1:state 1<cr><lf>');
else
    fprintf(device, ':pulse1:state 0<cr><lf>');
end
fscanf(device);
value = get(handles.BOnOff, 'Value');
if value == 1;
    fprintf(device, ':pulse2:state 1<cr><lf>');
else
    fprintf(device, ':pulse2:state 0<cr><lf>');
end
fscanf(device);
value = get(handles.COnOff, 'Value');
if value == 1;
    fprintf(device, ':pulse3:state 1<cr><lf>');
else
    fprintf(device, ':pulse3:state 0<cr><lf>');
end
fscanf(device);
value = get(handles.DOnOff, 'Value');
if value == 1;
    fprintf(device, ':pulse4:state 1<cr><lf>');
else
    fprintf(device, ':pulse4:state 0<cr><lf>');
end
fscanf(device);

%Updating Sync Source for each Channel
Value = get(handles.ChASource, 'Value');
if Value == 1;
    fprintf(device, ':pulse1:sync T0<cr><lf>');
elseif Value == 2;
    fprintf(device, ':pulse1:sync T0<cr><lf>');%T0 because it can't be CHA
elseif Value == 3;
    fprintf(device, ':pulse1:sync CHB<cr><lf>');
elseif Value == 4;
    fprintf(device, ':pulse1:sync CHC<cr><lf>');
elseif Value == 5;
    fprintf(device, ':pulse1:sync CHD<cr><lf>');
end
fscanf(device);
Value = get(handles.ChBSource, 'Value');
if Value == 1;
    fprintf(device, ':pulse2:sync T0<cr><lf>');
elseif Value == 2;
    fprintf(device, ':pulse2:sync CHA<cr><lf>');
elseif Value == 3;
    fprintf(device, ':pulse2:sync T0<cr><lf>');%T0 because it can't be CHB
elseif Value == 4;
    fprintf(device, ':pulse2:sync CHC<cr><lf>');
elseif Value == 5;
    fprintf(device, ':pulse2:sync CHD<cr><lf>');
end
fscanf(device);
Value = get(handles.ChCSource, 'Value');
if Value == 1;
    fprintf(device, ':pulse3:sync T0<cr><lf>');
elseif Value == 2;
    fprintf(device, ':pulse3:sync CHA<cr><lf>');
elseif Value == 3;
    fprintf(device, ':pulse3:sync CHB<cr><lf>');
elseif Value == 4;
    fprintf(device, ':pulse3:sync T0<cr><lf>');%T0 because it can't be CHA
elseif Value == 5;
    fprintf(device, ':pulse3:sync CHD<cr><lf>');
end
fscanf(device);
Value = get(handles.ChDSource, 'Value');
if Value == 1;
    fprintf(device, ':pulse4:sync T0<cr><lf>');
elseif Value == 2;
    fprintf(device, ':pulse4:sync CHA<cr><lf>');
elseif Value == 3;
    fprintf(device, ':pulse4:sync CHB<cr><lf>');
elseif Value == 4;
    fprintf(device, ':pulse4:sync CHC<cr><lf>');
elseif Value == 5;
    fprintf(device, ':pulse4:sync T0<cr><lf>');%T0 because it can't be CHA
end
fscanf(device);

%Updating pulse Width for each Channel
Value = ShiftDecimal(get(handles.AWidth, 'String'),-9);
fprintf(device, [':pulse1:width ' Value '<cr><lf>']);
Value = ShiftDecimal(get(handles.BWidth, 'String'),-9);
fprintf(device, [':pulse2:width ' Value '<cr><lf>']);
Value = ShiftDecimal(get(handles.CWidth, 'String'),-9);
fprintf(device, [':pulse3:width ' Value '<cr><lf>']);
Value = ShiftDecimal(get(handles.DWidth, 'String'),-9);
fprintf(device, [':pulse4:width ' Value '<cr><lf>']);
fscanf(device);

%Updating delay for each Channel
Value = ShiftDecimal(get(handles.ADelay, 'String'),-9);
fprintf(device, [':pulse1:delay ' Value '<cr><lf>']);
Value = ShiftDecimal(get(handles.BDelay, 'String'),-9);
fprintf(device, [':pulse2:delay ' Value '<cr><lf>']);
Value = ShiftDecimal(get(handles.CDelay, 'String'),-9);
fprintf(device, [':pulse3:delay ' Value '<cr><lf>']);
Value = ShiftDecimal(get(handles.DDelay, 'String'),-9);
fprintf(device, [':pulse4:delay ' Value '<cr><lf>']);
fscanf(device);

%Updating 'To' Period
Value = ShiftDecimal(get(handles.ToPeriod, 'String'),-6);
fprintf(device, [':spulse:period ' Value '<cr><lf>']);
fscanf(device);

%Updating Trigger Mode
if get(handles.NormalTrigger, 'Value') == 1;
    fprintf(device, ':spulse:external:mode disabled<cr><lf>');
elseif get(handles.TriggerTrigger, 'Value') == 1;
    fprintf(device, ':spulse:external:mode trigger<cr><lf>');
elseif get(handles.TriggerTrigger, 'Value') == 1;
    fprintf(device, ':spulse:external:mode gate<cr><lf>');
end
fscanf(device);

%Updating pulse mode of selected channel/To
channel = get(handles.ChannelSelect4Mode, 'Value');
channels = {':spulse',':pulse1',':pulse2',':pulse3',':pulse4'};
modes = {'normal', 'single', 'burst', 'dcycle'};
mode = 1;
if get(handles.SingleMode, 'Value') ==1;
    mode = 2;
elseif get(handles.BurstMode, 'Value') ==1;
    mode = 3;
elseif get(handles.DutyMode, 'Value') ==1;
    mode = 4;
end
channel = channels(channel);
mode = modes(mode);
fprintf(device, [channel{1} ':mode ' mode{1} '<cr><lf>']);
fscanf(device);

%Updating Burst, and Duty mode counters
channel = get(handles.ChannelSelect4Mode, 'Value');
channels = {':spulse',':pulse1',':pulse2',':pulse3',':pulse4'};
channel = channels(channel);
value = get(handles.BurstPulseCounter, 'String');
fprintf(device, [channel{1} ':bcounter ' value '<cr><lf>']);
fscanf(device);
value = get(handles.DutyPulseCounter, 'String');
fprintf(device, [channel{1} ':pcounter ' value '<cr><lf>']);
fscanf(device);
value = get(handles.DutyInhibitedCounter, 'String');
fprintf(device, [channel{1} ':ocounter ' value '<cr><lf>']);
fscanf(device);

fclose(device);
clear device;

% --- Executes on button press in ResetButton.
function ResetButton_Callback(hObject, eventdata, handles)
% hObject    handle to ResetButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global deviceLocation;
device = OpenQC9514Link(deviceLocation);

%retreiving state of each channel and displaying
fprintf(device, ':pulse1:state?<cr><lf>');
set(handles.AOnOff, 'Value', str2double(fscanf(device)));
fprintf(device, ':pulse2:state?<cr><lf>');
set(handles.BOnOff, 'Value', str2double(fscanf(device)));
fprintf(device, ':pulse3:state?<cr><lf>');
set(handles.COnOff, 'Value', str2double(fscanf(device)));
fprintf(device, ':pulse4:state?<cr><lf>');
set(handles.DOnOff, 'Value', str2double(fscanf(device)));

%retreiving pulse width of each channel and displaying
fprintf(device, ':pulse1:width?<cr><lf>');
read = ShiftDecimal(fscanf(device),9);
set(handles.AWidth,'String',read);
fprintf(device, ':pulse2:width?<cr><lf>');
read = ShiftDecimal(fscanf(device),9);
set(handles.BWidth,'String',read);
fprintf(device, ':pulse3:width?<cr><lf>');
read = ShiftDecimal(fscanf(device),9);
set(handles.CWidth,'String',read);
fprintf(device, ':pulse4:width?<cr><lf>');
read = ShiftDecimal(fscanf(device),9);
set(handles.DWidth,'String',read);

%retreiving pulse delay for each channel and displaying
fprintf(device, ':pulse1:delay?<cr><lf>');
read = ShiftDecimal(fscanf(device),9);
set(handles.ADelay,'String',read);
fprintf(device, ':pulse2:delay?<cr><lf>');
read = ShiftDecimal(fscanf(device),9);
set(handles.BDelay,'String',read);
fprintf(device, ':pulse3:delay?<cr><lf>');
read = ShiftDecimal(fscanf(device),9);
set(handles.CDelay,'String',read);
fprintf(device, ':pulse4:delay?<cr><lf>');
read = ShiftDecimal(fscanf(device),9);
set(handles.DDelay,'String',read);

%Retreiving and displaying Sync Source for each Channel
fprintf(device, ':pulse1:sync?<cr><lf>');
read = fscanf(device);
if ~isempty(regexp(read, 'T','once'));
    set(handles.ChASource, 'Value', 1);
elseif ~isempty(regexp(read, 'HA','once'));
    set(handles.ChASource, 'Value', 2);
elseif ~isempty(regexp(read, 'HB','once'));
    set(handles.ChASource, 'Value', 3);
elseif ~isempty(regexp(read, 'HC','once'));
    set(handles.ChASource, 'Value', 4);
elseif ~isempty(regexp(read, 'HD','once'));
    set(handles.ChASource, 'Value', 5);    
end
fprintf(device, ':pulse2:sync?<cr><lf>');
read = fscanf(device);
if ~isempty(regexp(read, 'T','once'));
    set(handles.ChBSource, 'Value', 1);
elseif ~isempty(regexp(read, 'HA','once'));
    set(handles.ChBSource, 'Value', 2);
elseif ~isempty(regexp(read, 'HB','once'));
    set(handles.ChBSource, 'Value', 3);
elseif ~isempty(regexp(read, 'HC','once'));
    set(handles.ChBSource, 'Value', 4);
elseif ~isempty(regexp(read, 'HD','once'));
    set(handles.ChBSource, 'Value', 5);    
end
fprintf(device, ':pulse3:sync?<cr><lf>');
read = fscanf(device);
if ~isempty(regexp(read, 'T','once'));
    set(handles.ChCSource, 'Value', 1);
elseif ~isempty(regexp(read, 'HA','once'));
    set(handles.ChCSource, 'Value', 2);
elseif ~isempty(regexp(read, 'HB','once'));
    set(handles.ChCSource, 'Value', 3);
elseif ~isempty(regexp(read, 'HC','once'));
    set(handles.ChCSource, 'Value', 4);
elseif ~isempty(regexp(read, 'HD','once'));
    set(handles.ChCSource, 'Value', 5);    
end
fprintf(device, ':pulse4:sync?<cr><lf>');
read = fscanf(device);
if ~isempty(regexp(read, 'T','once'));
    set(handles.ChDSource, 'Value', 1);
elseif ~isempty(regexp(read, 'HA','once'));
    set(handles.ChDSource, 'Value', 2);
elseif ~isempty(regexp(read, 'HB','once'));
    set(handles.ChDSource, 'Value', 3);
elseif ~isempty(regexp(read, 'HC','once'));
    set(handles.ChDSource, 'Value', 4);
elseif ~isempty(regexp(read, 'HD','once'));
    set(handles.ChDSource, 'Value', 5);    
end


%Retreiving Period for To and displaying
fprintf(device, ':spulse:period?<cr><lf>');
read = ShiftDecimal(fscanf(device),6);
set(handles.ToPeriod,'String',read);

%retreiving and displaying trigger mode
fprintf(device, ':spulse:external:mode?<cr><lf>');
read = fscanf(device);
if ~isempty(regexp(read, 'DIS', 'once'));
    set(handles.NormalTrigger, 'Value', 1);
else
    set(handles.NormalTrigger, 'Value', 0);
end
if ~isempty(regexp(read, 'TRIG', 'once'));
    set(handles.TriggerTrigger, 'Value', 1);
else
    set(handles.TriggerTrigger, 'Value', 0);
end
if ~isempty(regexp(read, 'GAT', 'once'));
    set(handles.GateTrigger, 'Value', 1);
else
    set(handles.GateTrigger, 'Value', 0);
end

%retreiving and displaying mode for selected channel/source
Channel = get(handles.ChannelSelect4Mode, 'Value');
if Channel == 1;
    fprintf(device, ':spulse:mode?<cr><lf>');
    read = fscanf(device);
    if ~isempty(regexp(read, 'NORM', 'once'));
        set(handles.NormalMode, 'Value', 1);
    else
        set(handles.NormalMode, 'Value', 0);
    end
    if ~isempty(regexp(read, 'SING', 'once'));
        set(handles.SingleMode, 'Value', 1);
    else
        set(handles.SingleMode, 'Value', 0);
    end
    if ~isempty(regexp(read, 'BURS', 'once'));
        set(handles.BurstMode, 'Value', 1);
    else
        set(handles.BurstMode, 'Value', 0);
    end
    if ~isempty(regexp(read, 'DCYC', 'once'));
        set(handles.DutyMode, 'Value', 1);
    else
        set(handles.DutyMode, 'Value', 0);
    end
else
    Channel = num2str(Channel-1);
    fprintf(device, strcat(':pulse',Channel,':cmode?<cr><lf>'));
    read = fscanf(device);
    if ~isempty(regexp(read, 'NORM', 'once'));
        set(handles.NormalMode, 'Value', 1);
    else
        set(handles.NormalMode, 'Value', 0);
    end
    if ~isempty(regexp(read, 'SINGL', 'once'));
        set(handles.SingleMode, 'Value', 1);
    else
        set(handles.SingleMode, 'Value', 0);
    end
    if ~isempty(regexp(read, 'BURS', 'once'));
        set(handles.BurstMode, 'Value', 1);
    else
        set(handles.BurstMode, 'Value', 0);
    end
    if ~isempty(regexp(read, 'DCYCL', 'once'));
        set(handles.DutyMode, 'Value', 1);
    else
        set(handles.DutyMode, 'Value', 0);
    end
end

%retreiving run status of pulse generator and displaying
fprintf(device, ':spulse:state?<cr><lf>');
read = str2double(fscanf(device));
if read == 1;
    set(handles.RunButton, 'BackgroundColor', [1 0 0]);
else
    set(handles.RunButton, 'BackgroundColor', [.33 .63 .82]);
end

%retreiving and displaying burst and duty pulse counters
channel = get(handles.ChannelSelect4Mode, 'Value');
channels = {':spulse',':pulse1',':pulse2',':pulse3',':pulse4'};
channel = channels(channel);

fprintf(device, [channel{1} ':bcounter?<cr><lf>']);
value = ShiftDecimal(fscanf(device),0);
set(handles.BurstPulseCounter, 'String', value);
fprintf(device, [channel{1} ':pcounter?<cr><lf>']);
value = ShiftDecimal(fscanf(device),0);
set(handles.DutyPulseCounter, 'String', value);
fprintf(device, [channel{1} ':ocounter?<cr><lf>']);
value = ShiftDecimal(fscanf(device),0);
set(handles.DutyInhibitedCounter, 'String', value);

fclose(device);
clear device;
    


% --- Executes on button press in SaveButton.
function SaveButton_Callback(hObject, eventdata, handles)
% hObject    handle to SaveButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Savegui


% --- Executes on button press in LoadButton.
function LoadButton_Callback(hObject, eventdata, handles)
% hObject    handle to LoadButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Loadgui

% --- Executes on button press in RunButton.
function RunButton_Callback(hObject, eventdata, handles)
% hObject    handle to RunButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%initiating run/stop command to pulse generator and changing the color of
%the button to display the change.
global deviceLocation;
device = OpenQC9514Link(deviceLocation);
color = get(hObject, 'BackgroundColor');
if color ==[1 0 0]
    fprintf(device, ':spulse:state 0<cr><lf>');
    set(handles.RunButton, 'BackgroundColor', [.33 .63 .82]);
else
    fprintf(device, ':spulse:state 1<cr><lf>');
    set(handles.RunButton, 'BackgroundColor', [1 0 0]);
end
fclose(device);
clear device;


% --- Executes on selection change in ChannelSelect4Mode.
function ChannelSelect4Mode_Callback(hObject, eventdata, handles)
% hObject    handle to ChannelSelect4Mode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns ChannelSelect4Mode contents as cell array
%        contents{get(hObject,'Value')} returns selected item from ChannelSelect4Mode


% --- Executes during object creation, after setting all properties.
function ChannelSelect4Mode_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ChannelSelect4Mode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in ChASource.
function ChASource_Callback(hObject, eventdata, handles)
% hObject    handle to ChASource (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns ChASource contents as cell array
%        contents{get(hObject,'Value')} returns selected item from ChASource


% --- Executes during object creation, after setting all properties.
function ChASource_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ChASource (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in ChBSource.
function ChBSource_Callback(hObject, eventdata, handles)
% hObject    handle to ChBSource (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns ChBSource contents as cell array
%        contents{get(hObject,'Value')} returns selected item from ChBSource


% --- Executes during object creation, after setting all properties.
function ChBSource_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ChBSource (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in ChCSource.
function ChCSource_Callback(hObject, eventdata, handles)
% hObject    handle to ChCSource (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns ChCSource contents as cell array
%        contents{get(hObject,'Value')} returns selected item from ChCSource


% --- Executes during object creation, after setting all properties.
function ChCSource_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ChCSource (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in ChDSource.
function ChDSource_Callback(hObject, eventdata, handles)
% hObject    handle to ChDSource (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns ChDSource contents as cell array
%        contents{get(hObject,'Value')} returns selected item from ChDSource


% --- Executes during object creation, after setting all properties.
function ChDSource_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ChDSource (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in AOnOff.
function AOnOff_Callback(hObject, eventdata, handles)
% hObject    handle to AOnOff (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%enabling/disabling channel
global deviceLocation;
device = OpenQC9514Link(deviceLocation);
value = get(hObject, 'Value');
fprintf(device, [':pulse1:state ' value '<cr><lf>']);
fscanf(device);
fclose(device);
clear device;

% Hint: get(hObject,'Value') returns toggle state of AOnOff


% --- Executes on button press in BOnOff.
function BOnOff_Callback(hObject, eventdata, handles)
% hObject    handle to BOnOff (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%enabling/disabling channel
global deviceLocation;
device = OpenQC9514Link(deviceLocation);
value = get(hObject, 'Value');
fprintf(device, [':pulse2:state ' value '<cr><lf>']);
fscanf(device);
fclose(device);
clear device;
% Hint: get(hObject,'Value') returns toggle state of BOnOff


% --- Executes on button press in COnOff.
function COnOff_Callback(hObject, eventdata, handles)
% hObject    handle to COnOff (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%enabling/disabling channel
global deviceLocation;
device = OpenQC9514Link(deviceLocation);
value = get(hObject, 'Value');
fprintf(device, [':pulse3:state ' value '<cr><lf>']);
fscanf(device);
fclose(device);
clear device;
% Hint: get(hObject,'Value') returns toggle state of COnOff


% --- Executes on button press in DOnOff.
function DOnOff_Callback(hObject, eventdata, handles)
% hObject    handle to DOnOff (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%enabling/disabling channel
global deviceLocation;
device = OpenQC9514Link(deviceLocation);
value = get(hObject, 'Value');
fprintf(device, [':pulse4:state ' value '<cr><lf>']);
fscanf(device);
fclose(device);
clear device;
% Hint: get(hObject,'Value') returns toggle state of DOnOff



function AWidth_Callback(hObject, eventdata, handles)
% hObject    handle to AWidth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of AWidth as text
%        str2double(get(hObject,'String')) returns contents of AWidth as a double


% --- Executes during object creation, after setting all properties.
function AWidth_CreateFcn(hObject, eventdata, handles)
% hObject    handle to AWidth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function BWidth_Callback(hObject, eventdata, handles)
% hObject    handle to BWidth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of BWidth as text
%        str2double(get(hObject,'String')) returns contents of BWidth as a double


% --- Executes during object creation, after setting all properties.
function BWidth_CreateFcn(hObject, eventdata, handles)
% hObject    handle to BWidth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function CWidth_Callback(hObject, eventdata, handles)
% hObject    handle to CWidth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of CWidth as text
%        str2double(get(hObject,'String')) returns contents of CWidth as a double


% --- Executes during object creation, after setting all properties.
function CWidth_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CWidth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function DWidth_Callback(hObject, eventdata, handles)
% hObject    handle to DWidth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of DWidth as text
%        str2double(get(hObject,'String')) returns contents of DWidth as a double


% --- Executes during object creation, after setting all properties.
function DWidth_CreateFcn(hObject, eventdata, handles)
% hObject    handle to DWidth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ADelay_Callback(hObject, eventdata, handles)
% hObject    handle to ADelay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ADelay as text
%        str2double(get(hObject,'String')) returns contents of ADelay as a double


% --- Executes during object creation, after setting all properties.
function ADelay_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ADelay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function BDelay_Callback(hObject, eventdata, handles)
% hObject    handle to BDelay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of BDelay as text
%        str2double(get(hObject,'String')) returns contents of BDelay as a double


% --- Executes during object creation, after setting all properties.
function BDelay_CreateFcn(hObject, eventdata, handles)
% hObject    handle to BDelay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function CDelay_Callback(hObject, eventdata, handles)
% hObject    handle to CDelay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of CDelay as text
%        str2double(get(hObject,'String')) returns contents of CDelay as a double


% --- Executes during object creation, after setting all properties.
function CDelay_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CDelay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function DDelay_Callback(hObject, eventdata, handles)
% hObject    handle to DDelay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of DDelay as text
%        str2double(get(hObject,'String')) returns contents of DDelay as a double


% --- Executes during object creation, after setting all properties.
function DDelay_CreateFcn(hObject, eventdata, handles)
% hObject    handle to DDelay (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ToPeriod_Callback(hObject, eventdata, handles)
% hObject    handle to ToPeriod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ToPeriod as text
%        str2double(get(hObject,'String')) returns contents of ToPeriod as a double


% --- Executes during object creation, after setting all properties.
function ToPeriod_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ToPeriod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in NormalTrigger.
function NormalTrigger_Callback(hObject, eventdata, handles)
% hObject    handle to NormalTrigger (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Setting trigger mode to normal
global deviceLocation;
device = OpenQC9514Link(deviceLocation);
fprintf(device, ':spulse:external:mode disabled<cr><lf>');
fscanf(device);
fclose(device);
clear device;

%unchecking other radio buttons
set(handles.TriggerTrigger, 'Value', 0);
set(handles.GateTrigger, 'Value', 0);
% Hint: get(hObject,'Value') returns toggle state of NormalTrigger


% --- Executes on button press in TriggerTrigger.
function TriggerTrigger_Callback(hObject, eventdata, handles)
% hObject    handle to TriggerTrigger (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Setting Trigger Mode to Trigger
global deviceLocation;
device = OpenQC9514Link(deviceLocation);
fprintf(device, ':spulse:external:mode trigger<cr><lf>');
fscanf(device);
fclose(device);
clear device;

%Unchecking Other Radio Buttons
set(handles.NormalTrigger, 'Value', 0);
set(handles.GateTrigger, 'Value', 0);
% Hint: get(hObject,'Value') returns toggle state of TriggerTrigger


% --- Executes on button press in GateTrigger.
function GateTrigger_Callback(hObject, eventdata, handles)
% hObject    handle to GateTrigger (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Setting Trigger Mode to Gate
global deviceLocation;
device = OpenQC9514Link(deviceLocation);
fprintf(device, ':spulse:external:mode gate<cr><lf>');
fscanf(device);
fclose(device);
clear device;

%Unchecking other radio Buttions
set(handles.TriggerTrigger, 'Value', 0);
set(handles.NormalTrigger, 'Value', 0);
% Hint: get(hObject,'Value') returns toggle state of GateTrigger


% --- Executes on button press in SingleMode.
function SingleMode_Callback(hObject, eventdata, handles)
% hObject    handle to SingleMode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Uncheching other radio buttons
set(handles.NormalMode, 'Value', 0);
set(handles.BurstMode, 'Value', 0);
set(handles.DutyMode, 'Value', 0);

%Setting mode to Single
global deviceLocation;
device = OpenQC9514Link(deviceLocation);
channel = get(handles.ChannelSelect4Mode, 'Value');
channels = {':spulse',':pulse1',':pulse2',':pulse3',':pulse4'};
modes = {'normal', 'single', 'burst', 'dcycle'};
mode = 1;
if get(handles.SingleMode, 'Value') ==1;
    mode = 2;
elseif get(handles.BurstMode, 'Value') ==1;
    mode = 3;
elseif get(handles.DutyMode, 'Value') ==1;
    mode = 4;
end
channel = channels(channel);
mode = modes(mode);
fprintf(device, [channel{1} ':mode ' mode{1} '<cr><lf>']);
fscanf(device);
fclose(device);
clear device;

%Displaying duty cycle panel
set(handles.DutyPanel, 'Visible', 'off');
set(handles.NormalPanel, 'Visible', 'off');
set(handles.SinglePanel, 'Visible', 'off');
set(handles.BurstPanel, 'Visible', 'off');
set(handles.SinglePanel, 'Visible', 'on');
% Hint: get(hObject,'Value') returns toggle state of SingleMode


% --- Executes on button press in NormalMode.
function NormalMode_Callback(hObject, eventdata, handles)
% hObject    handle to NormalMode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Unchecking other radio buttons
set(handles.SingleMode, 'Value', 0);
set(handles.BurstMode, 'Value', 0);
set(handles.DutyMode, 'Value', 0);

%setting mode to normal
global deviceLocation;
device = OpenQC9514Link(deviceLocation);
channel = get(handles.ChannelSelect4Mode, 'Value');
channels = {':spulse',':pulse1',':pulse2',':pulse3',':pulse4'};
modes = {'normal', 'single', 'burst', 'dcycle'};
mode = 1;
if get(handles.SingleMode, 'Value') ==1;
    mode = 2;
elseif get(handles.BurstMode, 'Value') ==1;
    mode = 3;
elseif get(handles.DutyMode, 'Value') ==1;
    mode = 4;
end
channel = channels(channel);
mode = modes(mode);
fprintf(device, [channel{1} ':mode ' mode{1} '<cr><lf>']);
fscanf(device);
fclose(device);
clear device;

%Displaying normal mode panel
set(handles.DutyPanel, 'Visible', 'off');
set(handles.NormalPanel, 'Visible', 'on');
set(handles.SinglePanel, 'Visible', 'off');
set(handles.BurstPanel, 'Visible', 'off');
% Hint: get(hObject,'Value') returns toggle state of NormalMode


% --- Executes on button press in BurstMode.
function BurstMode_Callback(hObject, eventdata, handles)
% hObject    handle to BurstMode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%unchecking other radio buttons
set(handles.SingleMode, 'Value', 0);
set(handles.NormalMode, 'Value', 0);
set(handles.DutyMode, 'Value', 0);

%setting mode to burst
global deviceLocation;
device = OpenQC9514Link(deviceLocation);
channel = get(handles.ChannelSelect4Mode, 'Value');
channels = {':spulse',':pulse1',':pulse2',':pulse3',':pulse4'};
modes = {'normal', 'single', 'burst', 'dcycle'};
mode = 1;
if get(handles.SingleMode, 'Value') ==1;
    mode = 2;
elseif get(handles.BurstMode, 'Value') ==1;
    mode = 3;
elseif get(handles.DutyMode, 'Value') ==1;
    mode = 4;
end
channel = channels(channel);
mode = modes(mode);
fprintf(device, [channel{1} ':mode ' mode{1} '<cr><lf>']);
fscanf(device);
fclose(device);
clear device;

%Displaying burst mode panel
set(handles.DutyPanel, 'Visible', 'off');
set(handles.NormalPanel, 'Visible', 'off');
set(handles.SinglePanel, 'Visible', 'off');
set(handles.BurstPanel, 'Visible', 'on');
% Hint: get(hObject,'Value') returns toggle state of BurstMode


% --- Executes on button press in DutyMode.
function DutyMode_Callback(hObject, eventdata, handles)
% hObject    handle to DutyMode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%unchecking other radio buttons
set(handles.SingleMode, 'Value', 0);
set(handles.BurstMode, 'Value', 0);
set(handles.NormalMode, 'Value', 0);

%setting mode to duty
global deviceLocation;
device = OpenQC9514Link(deviceLocation);
channel = get(handles.ChannelSelect4Mode, 'Value');
channels = {':spulse',':pulse1',':pulse2',':pulse3',':pulse4'};
modes = {'normal', 'single', 'burst', 'dcycle'};
mode = 1;
if get(handles.SingleMode, 'Value') ==1;
    mode = 2;
elseif get(handles.BurstMode, 'Value') ==1;
    mode = 3;
elseif get(handles.DutyMode, 'Value') ==1;
    mode = 4;
end
channel = channels(channel);
mode = modes(mode);
fprintf(device, [channel{1} ':mode ' mode{1} '<cr><lf>']);
fscanf(device);
fclose(device);
clear device;

%Displaying duty cycle panel
set(handles.DutyPanel, 'Visible', 'on');
set(handles.NormalPanel, 'Visible', 'off');
set(handles.SinglePanel, 'Visible', 'off');
set(handles.BurstPanel, 'Visible', 'off');
% Hint: get(hObject,'Value') returns toggle state of DutyMode



function BurstPulseCounter_Callback(hObject, eventdata, handles)
% hObject    handle to BurstPulseCounter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of BurstPulseCounter as text
%        str2double(get(hObject,'String')) returns contents of BurstPulseCounter as a double


% --- Executes during object creation, after setting all properties.
function BurstPulseCounter_CreateFcn(hObject, eventdata, handles)
% hObject    handle to BurstPulseCounter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function DutyInhibitedCounter_Callback(hObject, eventdata, handles)
% hObject    handle to DutyInhibitedCounter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of DutyInhibitedCounter as text
%        str2double(get(hObject,'String')) returns contents of DutyInhibitedCounter as a double


% --- Executes during object creation, after setting all properties.
function DutyInhibitedCounter_CreateFcn(hObject, eventdata, handles)
% hObject    handle to DutyInhibitedCounter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function DutyPulseCounter_Callback(hObject, eventdata, handles)
% hObject    handle to DutyPulseCounter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of DutyPulseCounter as text
%        str2double(get(hObject,'String')) returns contents of DutyPulseCounter as a double


% --- Executes during object creation, after setting all properties.
function DutyPulseCounter_CreateFcn(hObject, eventdata, handles)
% hObject    handle to DutyPulseCounter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
