function Serial9520
s=serial('COM7');
fopen(s)
set(s,'BaudRate',9600)
fprintf(s,'*IDN?<cr><lf>')
out1=fscanf(s)
fclose(s)
delete(s)
clear s
