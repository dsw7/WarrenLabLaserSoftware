function varargout = Savegui(varargin)
% SAVEGUI MATLAB code for Savegui.fig
%      SAVEGUI, by itself, creates a new SAVEGUI or raises the existing
%      singleton*.
%
%      H = SAVEGUI returns the handle to a new SAVEGUI or the handle to
%      the existing singleton*.
%
%      SAVEGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SAVEGUI.M with the given input arguments.
%
%      SAVEGUI('Property','Value',...) creates a new SAVEGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Savegui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Savegui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Savegui

% Last Modified by GUIDE v2.5 12-Jul-2013 15:06:26

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Savegui_OpeningFcn, ...
                   'gui_OutputFcn',  @Savegui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Savegui is made visible.
function Savegui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Savegui (see VARARGIN)

% Choose default command line output for Savegui
handles.output = hObject;
file = fopen('SaveInfo.txt');
list = textscan(file, '%s');
list = list{1,1};
j = 1;
for i = 1:12
    done = 0;
    line = '';
    k = 1;
    while done == 0
        text = list(j,1);
        if isequal(text{1}, '|');
            done = 1;
        else
            if i<10&k==1
            line = [line text{1} '  '];
            else
            line = [line text{1} ' ']; 
            end
        end
        j = j +1;
        k = k +1;
    end
    old = cellstr(get(handles.listbox1, 'String'));
    new = [old; {line}];
    set(handles.listbox1, 'String', new);
end
fclose(file);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Savegui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Savegui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function SaveLocation_Callback(hObject, eventdata, handles)
% hObject    handle to SaveLocation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of SaveLocation as text
%        str2double(get(hObject,'String')) returns contents of SaveLocation as a double


% --- Executes during object creation, after setting all properties.
function SaveLocation_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SaveLocation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Description_Callback(hObject, eventdata, handles)
% hObject    handle to Description (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Description as text
%        str2double(get(hObject,'String')) returns contents of Description as a double


% --- Executes during object creation, after setting all properties.
function Description_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Description (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in SaveButton1.
function SaveButton1_Callback(hObject, eventdata, handles)
% hObject    handle to SaveButton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global deviceLocation;
device = OpenQC9514Link(deviceLocation);
fprintf(device, ['*SAV ' get(handles.SaveLocation, 'String') '<cr><lf>']);
fscanf(device);
file = fopen('SaveInfo.txt');
list = textscan(file, '%s');
list = list{1,1};
j = 1;
set(handles.listbox1, 'String', 'Location - Description');
new = [];
for i = 1:12
    done = 0;
    line = '';
    k = 1;
    while done == 0
        text = list(j,1);
        if isequal(text{1}, '|');
            line = [line text{1}];
            done = 1;
        else
            if i<10&k==1
            line = [line text{1} '  '];
            else
            line = [line text{1} ' ']; 
            end
        end
        j = j +1;
        k = k +1;
    end
    old = cellstr(get(handles.listbox1, 'String'));
    new = [old; {line}];
    set(handles.listbox1, 'String', new)
end
SaveLocation = str2double(get(handles.SaveLocation, 'String'));
if SaveLocation < 10
    new{SaveLocation+1} = [num2str(SaveLocation) '  ' '- ' get(handles.Description, 'String') ' |'];
else
    new{SaveLocation+1} = [num2str(SaveLocation) ' ' '- ' get(handles.Description, 'String') ' |'];
end
set(handles.listbox1, 'String', new);
for i = 1:12;
    toPrint{i,1} = new{i+1};
end
fclose(file);
fclose(device);
clear device;
dlmcell('SaveInfo.txt', toPrint);
close(Savegui);


% --- Executes on button press in Cancel.
function Cancel_Callback(hObject, eventdata, handles)
% hObject    handle to Cancel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(Savegui);