function [ outString] = ShiftDecimal( inString, places )
number = str2num(inString)*10^places;
if places < 0
    outString = num2str(number, '%.9f');
else
    outString = num2str(number);
end

