function [ Output ] = CollectAverage( Averages, TimeBase, inputRange)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
if TimeBase < 7
    Requested.Board = 1280; %CS12502
else
    Requested.Board = 214;  %CS8422
end
systems = CsMl_Initialize;
CsMl_ErrorHandler(systems);

[ret, Scope] = CsMl_GetSystem(Requested);
CsMl_ErrorHandler(ret);

[ret, sysinfo] = CsMl_GetSystemInfo(Scope);
CsMl_ErrorHandler(ret);
pause(.2)
for i = 1:Averages
    setupDigitizer(TimeBase,inputRange, Scope);
    [ret] = CsMl_Commit(Scope);
    CsMl_ErrorHandler(ret, 1, Scope);
    ret = CsMl_Capture(Scope);
    CsMl_ErrorHandler(ret, 1, Scope);
        status = CsMl_QueryStatus(Scope);
    while status ~= 0
        status = CsMl_QueryStatus(Scope);
    end
    [ret, acqInfo] = CsMl_QueryAcquisition(Scope);
    transfer.Mode = CsMl_Translate('Default', 'TxMode');
    transfer.Segment = 1;
    transfer.Start = -acqInfo.TriggerHoldoff;
    transfer.Length = acqInfo.SegmentSize;
    transfer.Channel = 2;
    % Transfer the data
    [ret, data, actual] = CsMl_Transfer(Scope, transfer);
    if i == 1
        Output = data;
    else
        Output = ((i-1)*Output+data)/i;
    end
end
Output=Output';
CsMl_FreeSystem(Scope);
end

