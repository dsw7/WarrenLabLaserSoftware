function varargout = TAsetupGUI(varargin)
% TASETUPGUI MATLAB code for TAsetupGUI.fig
%      TASETUPGUI, by itself, creates a new TASETUPGUI or raises the existing
%      singleton*.
%
%      H = TASETUPGUI returns the handle to a new TASETUPGUI or the handle to
%      the existing singleton*.
%
%      TASETUPGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TASETUPGUI.M with the given input arguments.
%
%      TASETUPGUI('Property','Value',...) creates a new TASETUPGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before TAsetupGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to TAsetupGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
%       TAsetupGUI is the main function for operating Laser Table 1, it
%       provides control of the CS12502 and CS8422 Oscilloscopes, QC9514 Digital
%       Delay Generator, DK240 Monochromator, PMT power supply and shutter
%       box.
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Last Modified by GUIDE v2.5 14-Mar-2014 13:48:37

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @TAsetupGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @TAsetupGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before TAsetupGUI is made visible.
function TAsetupGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to TAsetupGUI (see VARARGIN)

% Choose default command line output for TAsetupGUI
handles.output = hObject;
set(handles.figure1,'Visible','off');
global PMTcontrol;
global Las1Shutter;
global Las2Shutter;
global ProbeShutter;
global Monochromator;
global Scope;
global pausetime;
global delayGen;
if isempty(varargin)
    instrreset
    %This section initializes the monochromator
    %Calls OpenDK240Link which locates the DK240 monochromator and then makes an open
    %connection. If the monochromator is not found, "device not found" is
    %returned and a notification will appear asking that you connect the
    %instrument, otherwise the handle to the instrument will be returned. 
    %This program cannot function without an active monochromator
    %connection.
    Monochromator = OpenDK240Link();
    if isequal(Monochromator, 'device not found')
        selection = questdlg('Monochromator not on, please turn on and select yes to continue.','Close','Yes','No','Yes');
        switch selection
            case 'Yes'
                Monochromator = OpenDK240Link();
                % @JJW DK240set(Monochromator, 'Position', 400);
            case 'No'
                instrreset
                delete(gcf);
                return
        end
    end
    
    %initialization of all global variables
    %
    %Scope is used to keep track of which Oscilloscope is currently active
    %while using the timer object "updatePlotTimer"
    Scope = 0;
    %PMTcontrol, Las1Shutter, Las2Shutter, and Probe Shutter are all channels
    %on the shutter box. 
    %PMTcontrol is an analog output channel, the shutterbox, which is an NI USB
    %6008, has two analog output channels ao0 and ao1, PMTcontrolLocation must
    %match the output channel that the PMT power supply is plugged into.
    PMTcontrolLocation = 'ao0';
    %The shutters operate off of the Digital I/O channels on the NI USB 6008.
    %The ShutterLocation variable must match the location of the physical
    %shutter on the shutterbox. There are 8 channels, beginning with 0 which
    %are labeled port0/line*, *=0,1...6,7.
    Las1ShutterLocation = 'port0/line0';
    Las2ShutterLocation = 'port0/line1';
    ProbeShutterLocation = 'port0/line2';
    %This try/catch block is designed to check if the shutter box is connected
    %to the computer. If it is not, a notification will appear asking for you
    %to plug in the box before proceeding. The setup cannot be opened without
    %the shutter box being active.
    try
        PMTcontrol = daq.createSession('ni');
        PMTcontrol.addAnalogOutputChannel('Dev1', PMTcontrolLocation, 'Voltage');
        Las1Shutter = daq.createSession('ni');
        Las1Shutter.addDigitalChannel('Dev1',Las1ShutterLocation, 'OutputOnly');
        Las2Shutter = daq.createSession('ni');
        Las2Shutter.addDigitalChannel('Dev1',Las2ShutterLocation, 'OutputOnly');
        ProbeShutter = daq.createSession('ni');
        ProbeShutter.addDigitalChannel('Dev1',ProbeShutterLocation, 'OutputOnly');
    catch err
        selection = questdlg('DIO/Valve Driver not connected, please connect and select yes to continue.','Close','Yes','No','Yes');
            switch selection
                case 'Yes'
                    PMTcontrol = daq.createSession('ni');
                    PMTcontrol.addAnalogOutputChannel('Dev1', 'ao0', 'Voltage');
                    Las1Shutter = daq.createSession('ni');
                    Las1Shutter.addDigitalChannel('Dev1','port0/line0', 'OutputOnly');
                    Las2Shutter = daq.createSession('ni');
                    Las2Shutter.addDigitalChannel('Dev1','port0/line1', 'OutputOnly');
                    ProbeShutter = daq.createSession('ni');
                    ProbeShutter.addDigitalChannel('Dev1','port0/line3', 'OutputOnly');
                case 'No'
                    fclose(Monochromator);
                    clear global Monochromator;
                    instrreset
                    delete(gcf);
                    return
            end
    end

    %This section initializes the digital delay generator
    pausetime = .1;
    %Calls OpenQC9514Link which locates the QC9514 Digital Delay Generator and then makes an open
    %connection. If the DDG is not found, "device not found" is
    %returned and a notification will appear asking that you connect the
    %instrument, otherwise a handle to the instrument will be returned.
    %This program cannot function without an active monochromator
    %connection.
    [delayGen] = OpenQC9514Link();
    %try/catch block signals if "device not found" is used and asks the user to
    %turn on or connect the digital delay generator
    try
        if isequal(delayGen, 'device not found')
            selection = questdlg('Digital Delay Generator not on, please turn on and select yes to continue.','Close','Yes','No','Yes');
            switch selection
                case 'Yes'
                    [delayGen] = OpenQC9514Link();
                   %setting pulse generator screen to automatically update
                    fprintf(delayGen, ':display:mode on<cr><lf>');
                    pause(pausetime);
                    fscanf(delayGen);
                    %setting pulse generator brightness to 2.
                    fprintf(delayGen, ':display:brightness 2<cr><lf>');
                    pause(pausetime);
                    fscanf(delayGen);
                    %Updating On/Off status of Channels A and B
                    fprintf(delayGen, ':pulse1:state 1<cr><lf>');
                    fscanf(delayGen);
                    fprintf(delayGen, ':pulse2:state 0<cr><lf>');
                    fscanf(delayGen);
                    %Running Digital Delay Generator
                    fprintf(delayGen, ':spulse:state 1<cr><lf>');
                    fscanf(delayGen);
                case 'No'
                    fclose(Monochromator);
                    clear global Monochromator;
                    instrreset
                    delete(gcf);
                    return
            end
        else
            %setting pulse generator screen to automatically update
            fprintf(delayGen, ':display:mode on<cr><lf>');
            pause(pausetime);
            fscanf(delayGen);
            %setting pulse generator brightness to 2.
            fprintf(delayGen, ':display:brightness 2<cr><lf>');
            pause(pausetime);
            fscanf(delayGen);
            %Updating On/Off status of Channels A and B
            fprintf(delayGen, ':pulse1:state 1<cr><lf>');
            fscanf(delayGen);
            fprintf(delayGen, ':pulse2:state 0<cr><lf>');
            fscanf(delayGen);
            %Running Digital Delay Generator
            fprintf(delayGen, ':spulse:state 1<cr><lf>');
            fscanf(delayGen)
        end
    catch err
    %setting pulse generator screen to automatically update
    fprintf(delayGen, ':display:mode on<cr><lf>');
    pause(pausetime);
    fscanf(delayGen);
    %setting pulse generator brightness to 2.
    fprintf(delayGen, ':display:brightness 2<cr><lf>');
    pause(pausetime);
    fscanf(delayGen);
    %Updating On/Off status of Channels A and B
    fprintf(delayGen, ':pulse1:state 1<cr><lf>');
    fscanf(delayGen);
    fprintf(delayGen, ':pulse2:state 0<cr><lf>');
    fscanf(delayGen);
    %Running Digital Delay Generator
    fprintf(delayGen, ':spulse:state 1<cr><lf>');
    fscanf(delayGen)
    end
end

%Sets initial Experiment radio button to Transient Adsorption
set(handles.TARadio, 'Value', 1);
%Sets initial timescale
set(handles.TimeBaseMenu, 'Value', 2);
%Sets initial probe lamp status to continuous wave
set(handles.ProbeLampStatic, 'Value', 1);
%Sets initial value for averages to 50
set(handles.AveragesBox, 'String', '50');
%Sets initial value for excitation wavelength to null
set(handles.ExcitationBox, 'String', '');
%Sets initial location of PMT to readout to 0
set(handles.PMTsetBox, 'String', '0');
%Sets initial color of Read button to Carolina Blue
set(handles.ReadButton, 'BackgroundColor', [.33 .63 .82]) 
%Sets Axes to specific y range
ylim([-.6, .01]);
set(handles.FilenameBox, 'String','C:\Users\myadmin\Desktop\Data')
set(handles.Las1Close, 'Value', 1)
Las1Shutter.outputSingleScan(0);
set(handles.Las2Close, 'Value', 1)
Las2Shutter.outputSingleScan(0);
set(handles.ProbeClose, 'Value', 1)
ProbeShutter.outputSingleScan(0);
%@JJW DK240set(Monochromator, 'Position', 400);
%global variables for information management. 
%QueueInfo is a structure which stores all of the appropriate variables 
%when the "Add" button is pressed for the Queue. QueueNames is a cell array
%that stores the information for the Queued list.
global QueueInfo;
QueueInfo(1).dataset = 0;
global QueueNames;
QueueNames = cell(1);
QueueNames{1,1} = '';

%This section obtains the current axes properties and displays them
xLimits = get(gca, 'Xlim');
yLimits = get(gca, 'YLim');
set(handles.YlowBox, 'String', yLimits(1,1));
set(handles.YhighBox, 'String', yLimits(1,2));
set(handles.XlowBox, 'String', xLimits(1,1));
set(handles.XhighBox, 'String', xLimits(1,2));


%This sets the selection of a cell on the QueueTable to trigger
%CellSelect3, which stores the location of the selected cell.
set(handles.QueueTable, 'CellSelectionCallback',@CellSelect3);

%Generates the Timer which allows for the continual update of the plot
%after the read button is selected.
handles.updatePlotTimer = timer('ExecutionMode', 'FixedRate', 'Period', .25, 'TimerFcn', {@updatePlot, handles});
%Triggers the closeGUI function when the option to close the gui is
%selected.
set(handles.figure1,'CloseRequestFcn',{@closeGUI,handles});
% Update handles structure
set(handles.ObservationBox, 'String', '400');
set(handles.figure1,'Visible','on');
guidata(hObject, handles);

% UIWAIT makes TAsetupGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);

function CellSelect3(hObject, eventData, handles)
%CellSelect3 is called when cells are selected from the Queuetable. It
%subsequently stores them in the global variable QueueCellSelect.
global QueueCellSelect;
QueueCellSelect = eventData.Indices;

function updatePlot(hObject, eventdata, handles)
%updatePlot is managed by the updatePlot Timer generated in the opening
%function.
%
%The updatePlot Timer is triggered by pressing the read button. It is on
%when the read button is red and is off when the read button is blue. It is
%used to repeatedly signal the selected oscilloscope to collect data and
%then displays it.

%Acquires global variable "Scope"
global Scope;
%If Scope does not contain a handle to an oscilloscope. The status is set
%to -1 to signal to the need to initialized data collection. If "Scope"
%does contain a handle, the status of the data acquisition is checked and
%recorded.
if Scope ~= 0;
    status = CsMl_QueryStatus(Scope);
else
    status = -1;
end

%Triggers if no oscilloscope is active
if status == -1
    %Obtains the Timebase that was selected
    selection = get(handles.TimeBaseMenu, 'Value');
    %Selects the appropriate oscilloscope for the desired Timescale
    if selection < 7
        Requested.Board = 1280; %CS12502
    else
        Requested.Board = 214;  %CS8422
    end
    %Initializes oscilloscope and checks for errors
    systems = CsMl_Initialize;
    CsMl_ErrorHandler(systems);
    %Obtains a handles to the desired oscillscope
    [ret, Scope] = CsMl_GetSystem(Requested);
    CsMl_ErrorHandler(ret);
    %calls setupDigitizer to prepare all data acquisition parameters for the
    %oscilloscope
    RangeValue = get(handles.InputRangeMenu, 'Value');
    RangeStrings = get(handles.InputRangeMenu, 'String');
    a = size(RangeStrings);
    newstring = '';
    for i = 1:a(2)
        if ~(isequal(RangeStrings(RangeValue, i),''))
            newstring = [newstring RangeStrings(RangeValue,i)];
        end
    end
    inputRange = str2double(newstring);
    setupDigitizer(selection, inputRange, Scope);
    %transmits all parameters to the scope
    [ret] = CsMl_Commit(Scope);
    CsMl_ErrorHandler(ret, 1, Scope);
    %Signals the oscilloscope to begin looking for a trigger event.
    ret = CsMl_Capture(Scope);
    CsMl_ErrorHandler(ret, 1, Scope);
end
%Triggers if status ==0, meaning that the oscilloscope has completed its
%data acquisition.
if status == 0
    %obtains parameter info from oscilloscope
    [ret, acqInfo] = CsMl_QueryAcquisition(Scope);
    %transfer structure is created to obtain desired data from oscilloscope
    transfer.Mode = CsMl_Translate('Default', 'TxMode');
    transfer.Segment = 1;
    transfer.Start = -acqInfo.TriggerHoldoff;
    transfer.Length = acqInfo.SegmentSize;
    %transfers from channel 2 on scope
    transfer.Channel = 2;
    % Transfer the data
    [ret, data, actual] = CsMl_Transfer(Scope, transfer);
    if min(data)< -.8
        global PMTcontrol;
        PMTcontrol.outputSingleScan(0);
        set(handles.PMTSlider, 'Value',0);
        set(handles.PMTsetBox,'String', num2str(0));
        warndlg('reading exceeded -.8, PMT Voltage set to 0');
    end
    %obtains parameters describing timescale of experiment
    [depth, triggerHoldoff, between] = FindTime(get(handles.TimeBaseMenu, 'Value'));
    %creates dataset representing the time
    Time = ((-triggerHoldoff*between):between:((depth-1)*between))';
    %plots data on GUI plot
    plot(handles.axes1, Time, data);
    %disconnects from oscilloscope
    ret = CsMl_FreeSystem(Scope);
    %removes handle from global variable
    Scope = 0;
    %updates plot information
    autoupdate(hObject,eventdata, handles);
end


% --- Outputs from this function are returned to the command line.
function varargout = TAsetupGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on selection change in TimeBaseMenu.
function TimeBaseMenu_Callback(hObject, eventdata, handles)
% hObject    handle to TimeBaseMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Frees any oscilloscopes that were in use to reinitialize with new
%parameters.
Value = get(hObject, 'Value');
if Value > 6
    ranges = ['10000';'1000 ';'500  '; '200  '; '100  '];
    set(handles.InputRangeMenu, 'String', ranges);
    set(handles.InputRangeMenu, 'Value', 1);
    set(handles.SlowAmpOffsetPanel, 'Visible', 'on');
else
    ranges = ['1000 ';'500  '; '200  '; '100  '];
    set(handles.InputRangeMenu, 'String', ranges);
    set(handles.InputRangeMenu, 'Value', 1);
    set(handles.SlowAmpOffsetPanel, 'Visible', 'off');
end
global Scope;
Scope = 0;
CsMl_FreeAllSystems;
plot(1,1);


% --- Executes during object creation, after setting all properties.
function TimeBaseMenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to TimeBaseMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in AxesAuto.
function AxesAuto_Callback(hObject, eventdata, handles)
% hObject    handle to AxesAuto (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if get(hObject, 'Value') == 1
    axis auto
else
    axis manual
end
autoupdate(hObject,eventdata, handles);



function XlowBox_Callback(hObject, eventdata, handles)
% hObject    handle to XlowBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
new = str2double(get(hObject, 'String'));
opposite = get(handles.XhighBox, 'String');
oppositenum = str2double(opposite);
while (new > oppositenum) || isnan(new)
    new = str2double(inputdlg(strcat('invalid bounds, enter value less than ', opposite,')')));
    if isempty(new)
        return;
    end
end
xlim([new,oppositenum]);
set(handles.AxesAuto, 'Value', 0);
autoupdate(hObject,eventdata, handles);


% --- Executes during object creation, after setting all properties.
function XlowBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to XlowBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function YlowBox_Callback(hObject, eventdata, handles)
% hObject    handle to YlowBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
new = str2double(get(hObject, 'String'));
opposite = get(handles.YhighBox, 'String');
oppositenum = str2double(opposite);
while (new > oppositenum) || isnan(new)
    new = str2double(inputdlg(strcat('invalid bounds, enter value less than ', opposite,')')));
    if isempty(new)
        return;
    end
end
ylim([new,oppositenum]);
set(handles.AxesAuto, 'Value', 0);
autoupdate(hObject,eventdata, handles);


% --- Executes during object creation, after setting all properties.
function YlowBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to YlowBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function XhighBox_Callback(hObject, eventdata, handles)
% hObject    handle to XhighBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
new = str2double(get(hObject, 'String'))
opposite = get(handles.XlowBox, 'String');
oppositenum = str2double(opposite)
while (new < oppositenum) || isnan(new)
    new = str2double(inputdlg(strcat('invalid bounds, enter value greater than ', opposite,')')));
    if isempty(new)
        return;
    end
end
xlim([oppositenum,new]);
set(handles.AxesAuto, 'Value', 0);
autoupdate(hObject,eventdata, handles);


% --- Executes during object creation, after setting all properties.
function XhighBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to XhighBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function YhighBox_Callback(hObject, eventdata, handles)
% hObject    handle to YhighBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
new = str2double(get(hObject, 'String'));
opposite = get(handles.YlowBox, 'String');
oppositenum = str2double(opposite);
while (new < oppositenum) || isnan(new)
    new = str2double(inputdlg(strcat('invalid bounds, enter value greater than ', opposite,')')));
    if isempty(new)
        return;
    end
end
ylim([oppositenum,new]);
set(handles.AxesAuto, 'Value', 0);
autoupdate(hObject,eventdata, handles);


% --- Executes during object creation, after setting all properties.
function YhighBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to YhighBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function autoupdate(hObject,eventdata, handles)
%updates plot information for display
xLimits = get(handles.axes1, 'Xlim');
yLimits = get(handles.axes1, 'YLim');
set(handles.YlowBox, 'String', yLimits(1,1));
set(handles.YhighBox, 'String', yLimits(1,2));
set(handles.XlowBox, 'String', xLimits(1,1));
set(handles.XhighBox, 'String', xLimits(1,2));



function FilenameBox_Callback(hObject, eventdata, handles)
% hObject    handle to FilenameBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function FilenameBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FilenameBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in SearchFilename.
function SearchFilename_Callback(hObject, eventdata, handles)
% hObject    handle to SearchFilename (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%opens Save menu
filename = GetFileName(get(handles.FilenameBox,'String'));
%displays selected location to user
set(handles.FilenameBox, 'String', filename);



function ExcitationBox_Callback(hObject, eventdata, handles)
% hObject    handle to ExcitationBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function ExcitationBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ExcitationBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ObservationBox_Callback(hObject, eventdata, handles)
% hObject    handle to ObservationBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global Monochromator;
%obtains value that user input into Observation wavelength box
uiInput = str2double(get(hObject,'String'));
%If value is invalid, a new value is requested before proceeding
if ~(uiInput < 1000) || ~(uiInput > 200)
    answer = inputdlg('Invalid Value, input a number between 200 and 1000','Error',1);
    uiInput =str2double(answer);
    if isempty(answer)
        set(hObject, 'String', DK240get(Monochromator, 'Position'));
        return;
    end
    while ~(uiInput < 1000) || ~(uiInput > 200)
        answer = inputdlg('Invalid Value, input a number between 200 and 1000','Error',1);
        if isempty(answer)
        set(hObject, 'String', DK240get(Monochromator, 'Position'));
        return;
        end
        uiInput =str2double(answer);
    end
    set(hObject, 'String', answer);
end
%new position is set on Monochromator
DK240set(Monochromator, 'Position', uiInput);


% --- Executes during object creation, after setting all properties.
function ObservationBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ObservationBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function AveragesBox_Callback(hObject, eventdata, handles)
% hObject    handle to AveragesBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --- Executes during object creation, after setting all properties.
function AveragesBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to AveragesBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function RepRateBox_Callback(hObject, eventdata, handles)
% hObject    handle to RepRateBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function RepRateBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to RepRateBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in TARadio.
function TARadio_Callback(hObject, eventdata, handles)
% hObject    handle to TARadio (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(hObject, 'Value', 1);
set(handles.LumRadio, 'Value', 0);
set(handles.FluorCheckbox, 'Visible', 'on');


% --- Executes on button press in LumRadio.
function LumRadio_Callback(hObject, eventdata, handles)
% hObject    handle to LumRadio (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(hObject, 'Value', 1);
set(handles.TARadio, 'Value', 0);
set(handles.FluorCheckbox, 'Value', 0);
set(handles.FluorCheckbox, 'Visible', 'off');


% --- Executes on button press in FluorCheckbox.
function FluorCheckbox_Callback(hObject, eventdata, handles)
% hObject    handle to FluorCheckbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if get(handles.LumRadio, 'Value') ==1
    set(hObject, 'Value', 0)
end


% --- Executes on button press in ProbeLampPulsed.
function ProbeLampPulsed_Callback(hObject, eventdata, handles)
% hObject    handle to ProbeLampPulsed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(hObject, 'Value', 1);
set(handles.ProbeLampStatic, 'Value', 0);
global pausetime;
global delayGen;
pausetime = .1;
%Updating On/Off status of ChannelB
fprintf(delayGen, ':pulse2:state 1<cr><lf>');
pause(pausetime);
fscanf(delayGen);


% --- Executes on button press in ProbeLampStatic.
function ProbeLampStatic_Callback(hObject, eventdata, handles)
% hObject    handle to ProbeLampStatic (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(hObject, 'Value', 1);
set(handles.ProbeLampPulsed, 'Value', 0);
global pausetime;
global delayGen;
pausetime = .1;
%Updating On/Off status of ChannelB
fprintf(delayGen, ':pulse2:state 0<cr><lf>');
pause(pausetime);
fscanf(delayGen);


% --- Executes on slider movement.
function PMTSlider_Callback(hObject, eventdata, handles)
% hObject    handle to PMTSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global PMTcontrol;
sliderValue = get(hObject,'Value');
%Adjusting for Scaler on PMT power supply
inputValue = 4.02*sliderValue;
PMTcontrol.outputSingleScan(inputValue);
set(handles.PMTsetBox,'String', num2str(sliderValue));


% --- Executes during object creation, after setting all properties.
function PMTSlider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PMTSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end




function PMTsetBox_Callback(hObject, eventdata, handles)
% hObject    handle to PMTsetBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global PMTcontrol;
setValue = get(hObject,'String');
setValue = str2double(setValue);
%checking to ensure value is between 0 and 1.
if (setValue > 1) || (setValue < 0)
    warndlg('Value invalid, voltage not altered')
    set(hObject,'String',num2str(get(handles.PMTSlider,'Value')));
else
    %Adjusting for Scaler on PMT power supply
    inputValue = 4.02*setValue;
    PMTcontrol.outputSingleScan(inputValue);
    set(handles.PMTSlider, 'Value',setValue);
end



% --- Executes during object creation, after setting all properties.
function PMTsetBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PMTsetBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in CommentBox.
function CommentBox_Callback(hObject, eventdata, handles)
% hObject    handle to CommentBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function CommentBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CommentBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in AddButton.
function AddButton_Callback(hObject, eventdata, handles)
% hObject    handle to AddButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%
%function stores all selected parameters for use during data acquisition
%and file saving.

%initializes global data storage variables
global QueueInfo;
global QueueNames;
%obtains filename
Filename = get(handles.FilenameBox,'String');
%checks to ensure filename has been input
if isequal(Filename, 'Input Filename')
    warndlg('File not named');
    return;
end
%selects correct location for data storage
if QueueInfo(1).dataset == 0
    dataset = 1;
else
    dataset = length(QueueInfo)+1;
end
%removes location String from filename for QueueNames Cell
name = Filename;
breaks = regexp(name, '\');
lengthBreaks = length(breaks);
lengthName = length(name);
name = name((breaks(1,lengthBreaks)+1):(lengthName-4));
%determines if filename has already been selected
for i = 1:length(QueueNames)
    if isequal(name, QueueNames{i,1})
        warndlg('Filename already exist')
        return;
    end
end
%stores dataset number
QueueInfo(dataset).dataset = dataset;
%Stores timebase value
QueueInfo(dataset).TimeBase = get(handles.TimeBaseMenu, 'Value');
%Stores whether a Fluorescence background will be taken
QueueInfo(dataset).FluorescenceBG = get(handles.FluorCheckbox, 'Value');
%stores whether the probelamp will be pulsed ore continuous wave
if get(handles.ProbeLampPulsed, 'Value') == 1
    QueueInfo(dataset).ProbeLamp = 'Pulsed';
else
    QueueInfo(dataset).ProbeLamp = 'CW';
end
%Stores the type of experiment that will be performed
if get(handles.TARadio, 'Value') ==1
    QueueInfo(dataset).Experiment = 'TA';
else
    QueueInfo(dataset).Experiment = 'Lum';
end
%Stores the number of averages to be taken
QueueInfo(dataset).Averages = str2double(get(handles.AveragesBox,'String'));
%Stores the RepRate
if get(handles.RepRateBox, 'Value') == 1
    QueueInfo(dataset).RepRate = 10;
else
    QueueInfo(dataset).RepRate = 1;
end
%Stores the complete filename and location for saving
QueueInfo(dataset).Filename = get(handles.FilenameBox,'String');
%stores the comments from the user
QueueInfo(dataset).Comments = get(handles.CommentBox, 'String');
%stores the excitation wavelength
QueueInfo(dataset).Excitation = get(handles.ExcitationBox, 'String');
%stores the observation wavelength
QueueInfo(dataset).Observation = str2double(get(handles.ObservationBox, 'String'));
%stores the pulse energy
QueueInfo(dataset).PulseEnergy = get(handles.PulseEnergyBox, 'String');
%stores input range
RangeValue = get(handles.InputRangeMenu, 'Value');
RangeStrings = get(handles.InputRangeMenu, 'String');
a = size(RangeStrings);
newstring = '';
for i = 1:a(2)
    if ~(isequal(RangeStrings(RangeValue, i),''))
        newstring = [newstring RangeStrings(RangeValue,i)];
    end
end
inputRange = str2double(newstring);
QueueInfo(dataset).InputRange = inputRange;
if isequal(QueueNames{1,1}, '')
    QueueNames{1,1} = name;
else
    QueueNames{length(QueueNames)+1,1} = name;
end
%renews the QueueTable data.
set(handles.QueueTable,'data',QueueNames);


% --- Executes on button press in ReadButton.
function ReadButton_Callback(hObject, eventdata, handles)
% hObject    handle to ReadButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%
%Turns the timer on and off for updating the plot.
Value = get(hObject, 'value');
if Value == 1
    set(hObject, 'BackgroundColor', [1 .2 .2]) 
    global Scope;
    Scope = 0;
    CsMl_FreeAllSystems;
    start(handles.updatePlotTimer);
else
    set(hObject, 'BackgroundColor', [.33 .63 .82]) 
    stop(handles.updatePlotTimer);
    CsMl_FreeAllSystems;
end

function closeGUI(src, evt, handles)
%executes upon selection of closeout button. disconnects from instruments,
%stops timers and clears global variables.
selection = questdlg('Are you sure?','Close','Yes','No','Yes');
switch selection
    case 'Yes'
        if isequal(get(handles.updatePlotTimer, 'Running'),'on')
            stop(handles.updatePlotTimer);
        end
        CsMl_FreeAllSystems();
        global delayGen;
        fprintf(delayGen, ':pulse2:state 0<cr><lf>');
        clear global QueueInfo;
        clear global QueueNames;
        global PMTcontrol
        PMTcontrol.outputSingleScan(0);
        instrreset
        delete(gcf)
    case 'No'
        return
end


% --- Executes on button press in ExecuteButton.
function ExecuteButton_Callback(hObject, eventdata, handles)
% hObject    handle to ExecuteButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%
% Deletes current GUI and opens the data acquisition GUI.
global QueueNames;
if isequal(QueueNames{1,1}, '')
    warndlg('No job queued');
    return;
end
selection = questdlg('Are you sure you want to continue?','Execute','Yes','No','Yes');
switch selection
    case 'Yes'
        global QueueInfo
        if isequal(get(handles.updatePlotTimer, 'Running'),'on')
            stop(handles.updatePlotTimer);
        end
        delete(gcf);
        CsMl_FreeAllSystems();
        ExecuteGui(QueueInfo);
    case 'No'
        return
end


% --- Executes on button press in Las1Open.
function Las1Open_Callback(hObject, eventdata, handles)
% hObject    handle to Las1Open (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Las1Shutter;
set(hObject, 'Value', 1);
set(handles.Las1Close, 'Value', 0);
Las1Shutter.outputSingleScan(1);


% --- Executes on button press in Las1Close.
function Las1Close_Callback(hObject, eventdata, handles)
% hObject    handle to Las1Close (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Las1Shutter;
set(hObject, 'Value', 1);
set(handles.Las1Open, 'Value', 0);
Las1Shutter.outputSingleScan(0);


% --- Executes on button press in Las2Open.
function Las2Open_Callback(hObject, eventdata, handles)
% hObject    handle to Las2Open (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Las2Shutter;
set(hObject, 'Value', 1);
set(handles.Las2Close, 'Value', 0);
Las2Shutter.outputSingleScan(1);


% --- Executes on button press in Las2Close.
function Las2Close_Callback(hObject, eventdata, handles)
% hObject    handle to Las2Close (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Las2Shutter;
set(hObject, 'Value', 1);
set(handles.Las2Open, 'Value', 0);
Las2Shutter.outputSingleScan(0);


% --- Executes on button press in ProbeOpen.
function ProbeOpen_Callback(hObject, eventdata, handles)
% hObject    handle to ProbeOpen (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global ProbeShutter;
set(hObject, 'Value', 1);
set(handles.ProbeClose, 'Value', 0);
ProbeShutter.outputSingleScan(1);


% --- Executes on button press in ProbeClose.
function ProbeClose_Callback(hObject, eventdata, handles)
% hObject    handle to ProbeClose (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global ProbeShutter;
set(hObject, 'Value', 1);
set(handles.ProbeOpen, 'Value', 0);
ProbeShutter.outputSingleScan(0);


function PulseEnergyBox_Callback(hObject, eventdata, handles)
% hObject    handle to PulseEnergyBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function PulseEnergyBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PulseEnergyBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in RemoveButton.
function RemoveButton_Callback(hObject, eventdata, handles)
% hObject    handle to RemoveButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%
%Removes selected data from the QueueTable
global QueueCellSelect;
global QueueInfo;
global QueueNames;
if isempty(QueueCellSelect);
    warndlg('No selection made');
    return;
end
sizeSelect = size(QueueCellSelect);
if sizeSelect(1) > 1
    warndlg('only one item may be selected');
    return;
end

QueueInfo(QueueCellSelect(1,1)) = '';
if length(QueueNames) == 1
    QueueNames{1,1} = '';
    QueueInfo(1).dataset = 0;
else
QueueNames = QueueNames(~strcmp(QueueNames,QueueNames{QueueCellSelect(1,1),1}));
end
set(handles.QueueTable, 'data',QueueNames);


% --- Executes on selection change in InputRangeMenu.
function InputRangeMenu_Callback(hObject, eventdata, handles)
% hObject    handle to InputRangeMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%Use this to obtain value
value = get(hObject, 'Value');
strings = get(hObject, 'String');
a = size(strings);
newstring = '';
for i = 1:a(2)
    if ~(isequal(strings(value, i),''))
        newstring = [newstring strings(value,i)];
    end
end
str2double(newstring);
% Hints: contents = cellstr(get(hObject,'String')) returns InputRangeMenu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from InputRangeMenu


% --- Executes during object creation, after setting all properties.
function InputRangeMenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to InputRangeMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function SlowAmpOffset_Callback(hObject, eventdata, handles)
% hObject    handle to SlowAmpOffset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of SlowAmpOffset as text
%        str2double(get(hObject,'String')) returns contents of SlowAmpOffset as a double


% --- Executes during object creation, after setting all properties.
function SlowAmpOffset_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SlowAmpOffset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
updatePlot(hObject, eventdata, handles)


% --- Executes during object creation, after setting all properties.
function pushbutton10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
