function [QC9514, location] = OpenQC9514Link(loc)
%OpenQC9514Link Opens communication with the QC9514 digital delay generator
%   input
%       loc = com location of pulse generator, not required
%
%   output
%       QC9514 = object containing device
if nargin == 1
    %connecting
    location = loc;
    QC9514 = serial(loc);
    try
        %opening communication
        fopen(QC9514);
        %Executing QC9514 echo command
        fprintf(QC9514,'*IDN?<cr><lf>');
        %pausing to allow QC9514 to process
        pause(.2);
        %retreiving echo
        response = fscanf(QC9514);
        read = regexp(response, '9514', 'once');
        if isempty(read)
            fclose(QC9514);
            clear QC9514;
            QC9514 = 'device not found 1';
        end
    catch
        %if an error occured, connections are closed
        fclose(QC9514);
        clear QC9514;
        QC9514 = 'device not found 2';
    end
%handles no input situation
else
    %serial locations to check
    COM ={'COM1','COM2','COM3','COM4','COM5','COM6','COM7','COM8'};
    %COM = {'COM6','COM7','COM8'};
    %value for looping
    i = 1;
    %boolean for connection made
    linked = 0;
    %while loop executes while link has not been made and all ports have
    %not been checked
    while (linked == 0)&&(i<=length(COM))
        %boolean for location possible
        available = 1;
        try
            %retreiving location to check from array
            location = COM{i};
            %Connection being made
            QC9514 = serial(location);
            %Opening communication
            fopen(QC9514);
            %executing echo to monochromotar
            fprintf(QC9514,'*IDN?<cr><lf>');
            %pausing to allow QC9514 to process
            pause(.2);
            if QC9514.BytesAvailable > 5
                %retreiving echo
                response = fscanf(QC9514);
            end
        catch
            %closing connection if QC9514 not present
            try
                fclose(QC9514);
                clear DK240;
            catch
            end
            QC9514 = 'device not found 3';
            available = 0;
        end
        %opening connection if device detected
        if available == 1;
            fprintf(QC9514,'*IDN?<cr><lf>');
            %pausing to allow QC9514 to process
            pause(.2);
            %retreiving echo
            if QC9514.BytesAvailable > 5
                response = fscanf(QC9514);
                read = regexp(response, '9514', 'once');
            else
                read = [];
            end
            %signifying link
            if ~isempty(read)
                linked = 1;
            else
                QC9514 = 'device not found 4';
            end
        end
        i = i+1;
    end
end

end

