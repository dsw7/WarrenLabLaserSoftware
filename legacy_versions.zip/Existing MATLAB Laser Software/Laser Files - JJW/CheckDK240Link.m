function [ Available ] = CheckDK240Link( device )
%CheckDK240Link Sends echo command to assure connection
%   input
%    device = variable representing monochromator
%   output
%    Available = boolean, returns 1 if connected, 0 if not.
fwrite(device, 27);
pause(.2);
response = fread(device, device.BytesAvailable);
if response == 27
    Available = 1;
else
    Available = 0;
end
end

