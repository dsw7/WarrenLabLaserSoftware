function [ Depth, TriggerHoldoff, between ] = setupDigitizer( TimeRangeValue, Range, handle )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
if TimeRangeValue == 1
    SampleRate = 5e8;
    Depth = 912;
    TriggerHoldoff = 112;
    between = 2e-9;
elseif TimeRangeValue == 2
    SampleRate = 5e8;
    Depth = 9008;
    TriggerHoldoff = 1008;
    between = 2e-9;
elseif TimeRangeValue == 3
    SampleRate = 2.5e8;
    Depth = 9008;
    TriggerHoldoff = 1008; 
    between = 4e-9;
elseif TimeRangeValue == 4
    SampleRate = 1.25e8;
    Depth = 11264;
    TriggerHoldoff = 1264;
    between = 8e-9;
elseif TimeRangeValue == 5
    SampleRate = 2.5e7;
    Depth = 9008;
    TriggerHoldoff = 1008; 
    between = 4e-8;
elseif TimeRangeValue == 6
    SampleRate = 2.5e7;
    Depth = 18000;
    TriggerHoldoff = 2000; 
    between = 4e-8;
elseif TimeRangeValue == 7
    SampleRate = 1e7;
    Depth = 90000;
    TriggerHoldoff = 10000; 
    between = 1e-7;
elseif TimeRangeValue == 8
    SampleRate = 2.5e6;
    Depth = 90000;
    TriggerHoldoff = 10000;
    between = 4e-7;
elseif TimeRangeValue == 9
    SampleRate = 1e6;
    Depth = 90000;
    TriggerHoldoff = 10000; 
    between = 1e-6;
elseif TimeRangeValue == 10
    SampleRate = 2e5;
    Depth = 90000;
    TriggerHoldoff = 10000; 
    between = 5e-6;
elseif TimeRangeValue == 11
    SampleRate = 1e5;
    Depth = 90000;
    TriggerHoldoff = 10000;  
    between = 1e-5;
elseif TimeRangeValue == 12
    SampleRate = 1e4;
    Depth = 90000;
    TriggerHoldoff = 10000;  
    between = 1e-4;
elseif TimeRangeValue == 13
    SampleRate = 2e3;
    Depth = 90000;
    TriggerHoldoff = 10000;  
    between = 5e-4;
else
    warndlg('Time Range Conversion Failed');   
end
[ret, sysinfo] = CsMl_GetSystemInfo(handle);
CsMl_ErrorHandler(ret, 1, handle);

acqInfo.SampleRate = SampleRate;
acqInfo.ExtClock = 0;
acqInfo.Mode = CsMl_Translate('Dual', 'Mode');
acqInfo.SegmentCount = 1;
acqInfo.Depth = Depth;
acqInfo.SegmentSize = Depth + TriggerHoldoff;
acqInfo.TriggerTimeout = 1000000;
acqInfo.TriggerHoldoff = TriggerHoldoff;
acqInfo.TriggerDelay = 0;
acqInfo.TimeStampConfig = 0;

[ret] = CsMl_ConfigureAcquisition(handle, acqInfo);
CsMl_ErrorHandler(ret, 1, handle);

% Set up all the channels even though
% they might not all be used. For example
% in a 2 board master / slave system, in single channel
% mode only channels 1 and 3 are used.

for i = 1:sysinfo.ChannelCount
    chan(i).Channel = i;
    chan(i).Coupling = CsMl_Translate('DC', 'Coupling');
    chan(i).DiffInput = 0;
    chan(i).InputRange = Range*2;
    if TimeRangeValue <7
        chan(i).Impedance = 50;
    else
        chan(i).Impedance = 1e6;
    end
    chan(i).DcOffset = 0;
    chan(i).DirectAdc = 0;
    chan(i).Filter = 0; 
end;   

[ret] = CsMl_ConfigureChannel(handle, chan);
CsMl_ErrorHandler(ret, 1, handle);

trig.Trigger = 1;
trig.Slope = CsMl_Translate('Positive', 'Slope');
trig.Level = 2;
trig.Source = 1;
trig.ExtCoupling = CsMl_Translate('DC', 'ExtCoupling');
trig.ExtRange = Range*2;

[ret] = CsMl_ConfigureTrigger(handle, trig);
CsMl_ErrorHandler(ret, 1, handle);
end

