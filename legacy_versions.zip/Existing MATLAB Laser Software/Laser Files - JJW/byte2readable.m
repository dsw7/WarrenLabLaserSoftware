function [ readable ] = byte2readable( hibyte,lowbyte )
%Converts hibyte to a readable number
readable = hibyte*256 +lowbyte;
end

