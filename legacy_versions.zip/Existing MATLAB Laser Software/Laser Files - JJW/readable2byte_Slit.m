function [ hibyte, lowbyte ] = readable2byte( readable )
%converts a readable number to its hibyte and lowbyte values
readable_slit = readable;
hibyte = floor(readable_slit/256);
lowbyte = rem((readable_slit - 256*hibyte),256);
end

