function [ hibyte, midbyte, lowbyte ] = readable2byte( readable )
%converts a readable number to its hibyte and lowbyte values
readable_nm = readable*100;
hibyte = floor(readable_nm/65336)
midbyte = floor((readable_nm - 65536*hibyte)/256)
lowbyte = rem((readable_nm - 65536*hibyte),256)
end

