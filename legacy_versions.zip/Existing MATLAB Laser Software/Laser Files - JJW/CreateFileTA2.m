function [ doc ] = CreateFileTA2(SegmentSize, TotalTime, Board, ProbeLamp, Averages, RepRate, Filename, Comments, PulseEnergy, Excitation, Observation, Time, deltaOD, TA, ProbeBG, FluorBG)
%UNTITLED5 Summary of this function goes here
%   Detailed explanation goes here
doc = cell(16+length(Time),1);
doc{1,1} = {'Transient Adsorption with Fluorescence Background'};
doc{2,1} = {''};
breaks = regexp(Filename, '\');
lengthBreaks = length(breaks);
lengthName = length(Filename);
name = Filename((breaks(1,lengthBreaks)+1):(lengthName-4));
doc{3,1} = {['Dataset: ' name]};
doc{4,1} = {['Comments: ' Comments]};
doc{5,1} = {['Datapoints: ' num2str(SegmentSize)]};
doc{6,1} = {['Total Time: ' num2str(TotalTime)]};
doc{7,1} = {['Scope: ' Board]};
doc{8,1} = {['Probe Lamp: ' ProbeLamp]};
doc{9,1} = {['Scope: ' Board]};
doc{10,1} = {['Averages: ' num2str(Averages)]};
doc{11,1} = {['Rep Rate: ' num2str(RepRate)]};
doc{12,1} = {['Pulse Energy: ' PulseEnergy]};
doc{13,1} = {['Excitation Wavelength: ' Excitation]};
doc{14,1} = {['Observation Wavelength: ' num2str(Observation)]};
doc{15,1} = {''};
doc{16,1} = {'Time , deltaOD , rawTA , Probe BG , FluorBG'};
j = 1;
for i = 17:(length(Time)+16)
    doc{i,1} = {[num2str(Time(j,1)) ' , ' num2str(deltaOD(j,1)) ' , ' num2str(TA(j,1)) ' , ' num2str(ProbeBG(j,1)) ' , ' num2str(FluorBG(j,1))]};
    j = j +1;
end
end

