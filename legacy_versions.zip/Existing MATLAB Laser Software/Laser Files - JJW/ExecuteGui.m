function varargout = ExecuteGui(varargin)
% EXECUTEGUI MATLAB code for ExecuteGui.fig
%      EXECUTEGUI, by itself, creates a new EXECUTEGUI or raises the existing
%      singleton*.
%
%      H = EXECUTEGUI returns the handle to a new EXECUTEGUI or the handle to
%      the existing singleton*.
%
%      EXECUTEGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in EXECUTEGUI.M with the given input arguments.
%
%      EXECUTEGUI('Property','Value',...) creates a new EXECUTEGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ExecuteGui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ExecuteGui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%       
%       Cannot run as standalone, must be opened from TAsetupGUI
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Last Modified by GUIDE v2.5 16-Jan-2014 10:37:22

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ExecuteGui_OpeningFcn, ...
                   'gui_OutputFcn',  @ExecuteGui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ExecuteGui is made visible.
function ExecuteGui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ExecuteGui (see VARARGIN)

% Choose default command line output for ExecuteGui
handles.output = hObject;

guidata(hObject, handles);

%Initializes global variables
global QueueNames;
global dataset;
dataset = 1;
global complete;
complete = 1;
global progress;
progress = 0;
global cluster;
cluster = parcluster();
global CompletedNames;
CompletedNames{1,1} = '';
global PlottedDataNames;
PlottedDataNames{1,1} = '';
global color;
color = 0;
global cstring;
cstring = 'krbgmc';

%set axes control to lower plot
set(handles.PastRadio, 'Value', 1);
%set axis to auto
set(handles.AutoAxes, 'Value', 1);
%update display for plot values
xLimits = get(handles.PastAxes, 'Xlim');
yLimits = get(handles.PastAxes, 'YLim');
set(handles.YlowBox, 'String', yLimits(1,1));
set(handles.YhighBox, 'String', yLimits(1,2));
set(handles.XlowBox, 'String', xLimits(1,1));
set(handles.XhighBox, 'String', xLimits(1,2));

%displays queuelist
set(handles.QueueTable,'data',QueueNames);
%This sets the selection of a cell on the DisplayedTable to trigger
%CellSelect, which stores the location of the selected cell.
set(handles.DisplayedTable, 'CellSelectionCallback',@CellSelect);
%This sets the selection of a cell on the AvailableTable to trigger
%CellSelect, which stores the location of the selected cell.
set(handles.AvailableTable, 'CellSelectionCallback',@CellSelect2);
%Creates Timer to operate second core for dataacquisition
handles.ExecuteTimer = timer('ExecutionMode', 'FixedRate', 'Period', 1, 'TimerFcn', {@Execute, handles});
% Update handles structure
guidata(hObject, handles);
%executes closeGUI function when GUI closeout is selected
set(handles.figure1,'CloseRequestFcn',{@closeGUI,handles});
%Starts data acquisition
start(handles.ExecuteTimer);

% UIWAIT makes ExecuteGui wait for user response (see UIRESUME)
% uiwait(handles.figure1);
function CellSelect(hObject,eventData,handles)
%stores location of selected cell on displayed table
global DisplayedCellSelect;
DisplayedCellSelect = eventData.Indices;

function CellSelect2(hObject,eventData,handles)
%stores location of selected cell on available table
global AvailableCellSelect;
AvailableCellSelect = eventData.Indices;

function Execute(hObject, eventdata, handles)
%Executes on for Execute Timer. Controls operation of 2nd core.
%Acquires all global variables
global QueueInfo;
global dataset;
if dataset > length(QueueInfo);
    return
end
global QueueNames;
global complete;
global Monochromator;
global PMTcontrol;
global Las1Shutter;
global Las2Shutter;
global ProbeShutter;
global delayGen;
global CurrentData;
global progress;
global cluster;
global job;
global CompletedData;
global CompletedNames;
global PlottedDataNames;
global PlottedData;
global color;
global cstring;
%Proceeds if there is no active data acquistions
if complete == 1;
    %sets currently active box to next dataset
    set(handles.CurrentDataBox, 'String', QueueNames{1,1});
    %sets currently active box to carolina blue
    set(handles.CurrentDataBox, 'BackgroundColor', [.33 .63 .82]) 
    %stores dataset name for display in available table
    if isequal(CompletedNames{1,1},'')
        CompletedNames{1,1} = QueueNames{1,1};
    else
        CompletedNames{length(CompletedNames)+1,1} = QueueNames{1,1};
    end
    %deletes dataset from queue list
    if length(QueueNames)>1
        QueueNames = QueueNames(~strcmp(QueueNames,QueueNames{1,1}));
    else
        QueueNames{1,1} = '';
    end
    set(handles.QueueTable,'data',QueueNames);
    %Sets Monochromator to appropriate wavelength
    DK240set(Monochromator,'Position', QueueInfo(dataset).Observation);
    pause(1.4)
    %Opens Las1Shutter
    Las1Shutter.outputSingleScan(1);
    %Ensures Laser is receiving pulse signal
    fprintf(delayGen, ':pulse1:state 1<cr><lf>');
    fscanf(delayGen);
    %sets probe lamp to desired state
    if isequal(QueueInfo(dataset).ProbeLamp, 'Pulsed');
        fprintf(delayGen, ':pulse2:state 1<cr><lf>');
        fscanf(delayGen);
    else
        fprintf(delayGen, ':pulse2:state 0<cr><lf>');
        fscanf(delayGen);
    end
    %selects appropriate oscilloscope
    if QueueInfo(dataset).TimeBase < 7
        QueueInfo(dataset).Board = 'CS12502';
    else
        QueueInfo(dataset).Board = 'CS8422';
    end
    complete = 0;
end
%Data Acquisition Switchboard
%Experiment Switch: Case TA or Lum

switch QueueInfo(dataset).Experiment
    case 'TA'
        %TA First Switch: Case Fluorescence Background Yes or No
        switch QueueInfo(dataset).FluorescenceBG
            %No Fluorescence Background
            case 0
                %TA Second Switch: Progress 0,1,2,3
                switch progress
                    %Data Acquisition has not began
                    case 0
                        %Open Laser and Probe Shutters
                        Las2Shutter.outputSingleScan(1);
                        ProbeShutter.outputSingleScan(1);
                        %Generate Time Data
                        [depth, triggerHoldoff, between] = FindTime(QueueInfo(dataset).TimeBase);
                        QueueInfo(dataset).SegmentSize = depth+triggerHoldoff;
                        QueueInfo(dataset).TotalTime =(depth-1)*between+triggerHoldoff*between;
                        CurrentData.Time = ((-triggerHoldoff*between):between:((depth-1)*between))';
                        %Generate Empty datasets for storage
                        CurrentData.Final = zeros(1,QueueInfo(dataset).SegmentSize);
                        CurrentData.TA = zeros(1,QueueInfo(dataset).SegmentSize);
                        CurrentData.ProbeBG = zeros(1,QueueInfo(dataset).SegmentSize);
                        %sends job to 2nd core for acquisition of Transient
                        %Absorption data
                        job = batch(cluster,@CollectAverage, 1, {QueueInfo(dataset).Averages,QueueInfo(dataset).TimeBase, QueueInfo(dataset).InputRange});
                        %Sets progress to 1
                        progress = 1;
                    %Data Acquisition of Transient Absorption data has been
                    %initialized
                    case 1
                        %try/catch to determine if job is complete, if yes,
                        %proceed, if no, delay until next call
                        try
                            fetched = fetchOutputs(job);
                        catch err
                            return;
                        end
                        %stores data gathered from job
                        CurrentData.TA = fetched{1,1};
                        %close Laser shutter
                        Las2Shutter.outputSingleScan(0);
                        %plot raw TA data on top Axes
                        hold(handles.NowAxes, 'off');
                        set(handles.ShowingText, 'String', get(handles.CurrentDataBox, 'String'));
                        plot(handles.NowAxes, CurrentData.Time, CurrentData.TA, 'Color', 'blue');
                        %sends job to 2nd core for acquisition of probe
                        %background
                        job = batch(cluster,@CollectAverage, 1, {QueueInfo(dataset).Averages,QueueInfo(dataset).TimeBase, QueueInfo(dataset).InputRange});
                        %sets progress to 2
                        progress = 2;
                    %Data acquisition for Probe Background data has been
                    %initialized
                    case 2
                        %try/catch to determine if job is complete, if yes,
                        %proceed, if no, delay until next call
                        try
                            fetched = fetchOutputs(job);
                        catch err
                            return;
                        end
                        %Stores data obtained from job
                        CurrentData.ProbeBG = fetched{1,1};
                        %plots result on top Axes
                        hold(handles.NowAxes, 'on');
                        plot(handles.NowAxes, CurrentData.Time, CurrentData.ProbeBG, 'Color', 'green');
                        %creates deltaOD dataset
                        CurrentData.Final = -log(CurrentData.TA./CurrentData.ProbeBG);
                        plot(handles.NowAxes, CurrentData.Time, CurrentData.Final, 'Color', 'black');
                        %sends job to 2nd core for creation of output csv
                        %file for saving
                        job = batch(cluster,@CreateFileTA1, 1, {QueueInfo(dataset).SegmentSize, QueueInfo(dataset).TotalTime, QueueInfo(dataset).Board, QueueInfo(dataset).ProbeLamp, QueueInfo(dataset).Averages, QueueInfo(dataset).RepRate, QueueInfo(dataset).Filename, QueueInfo(dataset).Comments, QueueInfo(dataset).PulseEnergy, QueueInfo(dataset).Excitation, QueueInfo(dataset).Observation, CurrentData.Time, CurrentData.Final, CurrentData.TA, CurrentData.ProbeBG});
                        %sets progress to 3
                        progress = 3;
                    %csv file creation has been initialized
                    case 3
                        %try/catch to determine if job is complete, if yes,
                        %proceed, if no, delay until next call
                        try
                            fetched = fetchOutputs(job);
                        catch err
                            return;
                        end
                        %retreives document that has been created
                        doc = fetched{1,1};
                        %saves document as a csv file
                        dlmcell(QueueInfo(dataset).Filename,doc);
                        %plots final result on lower Axes
                        hold(handles.PastAxes, 'on');
                        CompletedData(dataset).Time = CurrentData.Time;
                        CompletedData(dataset).data = CurrentData.Final;
                        %selects color for plot
                        if color > 6
                            color = 0;
                        end
                        col = cstring(mod(color,6)+1);
                        color = color +1;
                        if isequal(PlottedDataNames{1,1},'')
                            PlottedDataNames{1,1} = get(handles.CurrentDataBox,'String');
                            PlottedData{1,1} = plot(handles.PastAxes, CompletedData(dataset).Time, CompletedData(dataset).data, 'Color', col);
                        else
                            PlottedDataNames{length(PlottedDataNames)+1,1}=get(handles.CurrentDataBox,'String');
                            PlottedData{length(PlottedData)+1,1} = plot(handles.PastAxes, CompletedData(dataset).Time, CompletedData(dataset).data, 'Color', col);
                        end
                        %renews data tables
                        set(handles.AvailableTable, 'data', CompletedNames);
                        set(handles.DisplayedTable, 'data', PlottedDataNames);
                        %if this was the last dataset to be taken, shutters
                        %are closed, probe lamp is set to CW and the user
                        %is notified that data acquisition has ceased.
                        if dataset == length(QueueInfo)
                            PMTcontrol.outputSingleScan(0);
                            Las2Shutter.outputSingleScan(0);
                            Las1Shutter.outputSingleScan(0);
                            ProbeShutter.outputSingleScan(0);
                            fprintf(delayGen, ':pulse2:state 0<cr><lf>');
                            set(handles.CurrentDataBox, 'BackgroundColor', [1 .2 .2]);
                            set(handles.CurrentDataBox, 'String', '');
                        end
                        %all variables are renewed for next data set
                        clear global CurrentData;
                        progress = 0;
                        complete = 1;
                        dataset = dataset+1;
                end
            %Fluorescence background will be taken
            case 1
                switch progress
                    %data acquisition has not begun
                    case 0
                        %Shutters opened
                        Las2Shutter.outputSingleScan(1);
                        ProbeShutter.outputSingleScan(1);
                        %Time values created
                        [depth, triggerHoldoff, between] = FindTime(QueueInfo(dataset).TimeBase);
                        QueueInfo(dataset).SegmentSize = depth+triggerHoldoff;
                        QueueInfo(dataset).TotalTime =(depth-1)*between+triggerHoldoff*between;
                        CurrentData.Time = ((-triggerHoldoff*between):between:((depth-1)*between))';
                        %datasets initialized
                        CurrentData.Final = zeros(1,QueueInfo(dataset).SegmentSize);
                        CurrentData.TA = zeros(1,QueueInfo(dataset).SegmentSize);
                        CurrentData.ProbeBG = zeros(1,QueueInfo(dataset).SegmentSize);
                        CurrentData.FluorBG = zeros(1,QueueInfo(dataset).SegmentSize);
                        %job for data acquisition of Transient absorption
                        %data sent to 2nd core
                        job = batch(cluster,@CollectAverage, 1, {QueueInfo(dataset).Averages,QueueInfo(dataset).TimeBase, QueueInfo(dataset).InputRange});
                        %progress updated to 1
                        progress = 1;
                    %data acquisition for TA data has been initialized
                    case 1
                        %try/catch to determine if job is complete, if yes,
                        %proceed, if no, delay until next call
                        try
                            fetched = fetchOutputs(job);
                        catch err
                            return;
                        end
                        %retreives data from job
                        CurrentData.TA = fetched{1,1};
                        %closes Laser shutter for Probed Background
                        Las2Shutter.outputSingleScan(0);
                        %plots data
                        hold(handles.NowAxes, 'off');
                        set(handles.ShowingText, 'String', get(handles.CurrentDataBox, 'String'));
                        plot(handles.NowAxes, CurrentData.Time, CurrentData.TA, 'Color', 'blue');
                        %sends probe background job to 2nd core
                        job = batch(cluster,@CollectAverage, 1, {QueueInfo(dataset).Averages,QueueInfo(dataset).TimeBase, QueueInfo(dataset).InputRange});
                        %progress updated to 2
                        progress = 2;
                    %data acquisition for probe background initialized    
                    case 2
                        %try/catch to determine if job is complete, if yes,
                        %proceed, if no, delay until next call
                        try
                            fetched = fetchOutputs(job);
                        catch err
                            return;
                        end
                        %data retreived from job
                        CurrentData.ProbeBG = fetched{1,1};
                        %Laser shutter opened and probe shutter closed
                        Las2Shutter.outputSingleScan(1);
                        ProbeShutter.outputSingleScan(0);
                        %plots data
                        hold(handles.NowAxes, 'on');
                        plot(handles.NowAxes, CurrentData.Time, CurrentData.ProbeBG);
                        %sends data acquisition job for fluorescence
                        %background to 2nd core
                        job = batch(cluster,@CollectAverage, 1, {QueueInfo(dataset).Averages,QueueInfo(dataset).TimeBase, QueueInfo(dataset).InputRange});
                        %progress updated to 3
                        progress = 3;
                    %data acquisition for fluorescence BG initialized
                    case 3
                        %try/catch to determine if job is complete, if yes,
                        %proceed, if no, delay until next call
                        try
                            fetched = fetchOutputs(job);
                        catch err
                            return;
                        end
                        %retreives job data
                        CurrentData.FluorBG = fetched{1,1};
                        %plots job data
                        plot(handles.NowAxes, CurrentData.Time, CurrentData.FluorBG, 'Color', 'red');
                        %corrects to deltaOD and plots
                        CurrentData.Final = -log((CurrentData.TA-CurrentData.FluorBG)./CurrentData.ProbeBG);
                        plot(handles.NowAxes, CurrentData.Time, CurrentData.Final, 'Color', 'black');
                        %sends job to 2nd core for file creation
                        job = batch(cluster,@CreateFileTA2, 1, {QueueInfo(dataset).SegmentSize, QueueInfo(dataset).TotalTime, QueueInfo(dataset).Board, QueueInfo(dataset).ProbeLamp, QueueInfo(dataset).Averages, QueueInfo(dataset).RepRate, QueueInfo(dataset).Filename, QueueInfo(dataset).Comments, QueueInfo(dataset).PulseEnergy, QueueInfo(dataset).Excitation, QueueInfo(dataset).Observation, CurrentData.Time, CurrentData.Final, CurrentData.TA, CurrentData.ProbeBG, CurrentData.FluorBG});
                        %progress updated to 4
                        progress = 4;
                    %file creation job initialized
                    case 4
                        %try/catch to determine if job is complete, if yes,
                        %proceed, if no, delay until next call
                        try
                            fetched = fetchOutputs(job);
                        catch err
                            return;
                        end
                        %retreive job data
                        doc = fetched{1,1};
                        %saves as csv file
                        dlmcell(QueueInfo(dataset).Filename,doc);
                        %plots data on lower plot
                        hold(handles.PastAxes, 'on');
                        CompletedData(dataset).Time = CurrentData.Time;
                        CompletedData(dataset).data = CurrentData.Final;
                        %selects color for plotting
                        if color > 6
                            color = 0;
                        end
                        col = cstring(mod(color,6)+1);
                        color = color +1;
                        if isequal(PlottedDataNames{1,1},'')
                            PlottedDataNames{1,1} = get(handles.CurrentDataBox,'String');
                            PlottedData{1,1} = plot(handles.PastAxes, CompletedData(dataset).Time, CompletedData(dataset).data,'Color',col);
                        else
                            PlottedDataNames{length(PlottedDataNames)+1,1}=get(handles.CurrentDataBox,'String');
                            PlottedData{length(PlottedData)+1,1} = plot(handles.PastAxes, CompletedData(dataset).Time, CompletedData(dataset).data,'Color', col);
                        end
                        %renews data tables
                        set(handles.AvailableTable, 'data', CompletedNames);
                        set(handles.DisplayedTable, 'data', PlottedDataNames);
                        %if this was the last dataset to be taken, shutters
                        %are closed, probe lamp is set to CW and the user
                        %is notified that data acquisition has ceased.
                        if dataset == length(QueueInfo)
                            PMTcontrol.outputSingleScan(0);
                            Las2Shutter.outputSingleScan(0);
                            Las1Shutter.outputSingleScan(0);
                            ProbeShutter.outputSingleScan(0);
                            fprintf(delayGen, ':pulse2:state 0<cr><lf>');
                            set(handles.CurrentDataBox, 'BackgroundColor', [1 .2 .2]);
                            set(handles.CurrentDataBox, 'String', '');
                        end
                        %resets data acquisition variables for next job
                        clear global CurrentData;
                        progress = 0;
                        complete = 1;
                        dataset = dataset+1;
                end
        end
        autoupdate2(hObject,eventdata, handles);
    %Luminescence Acquisition
    case 'Lum'
        switch progress
            %data acquisition has not begun
            case 0
                %Opens Laser shutter, closes probe shutter
                Las2Shutter.outputSingleScan(1);
                ProbeShutter.outputSingleScan(0);
                %generates time data
                [depth, triggerHoldoff, between] = FindTime(QueueInfo(dataset).TimeBase);
                QueueInfo(dataset).SegmentSize = depth+triggerHoldoff;
                QueueInfo(dataset).TotalTime =(depth-1)*between+triggerHoldoff*between;
                CurrentData.Time = ((-triggerHoldoff*between):between:((depth-1)*between))';
                CurrentData.Lum = zeros(1,QueueInfo(dataset).SegmentSize);
                %sends job to 2nd core for acquistion of luminescence data
                job = batch(cluster,@CollectAverage, 1, {QueueInfo(dataset).Averages,QueueInfo(dataset).TimeBase, QueueInfo(dataset).InputRange});
                %progress updated to 1
                progress = 1;
            case 1
                %try/catch to determine if job is complete, if yes,
                %proceed, if no, delay until next call
                try
                    fetched = fetchOutputs(job);
                catch err
                    return;
                end
                %retreives data from job
                CurrentData.Lum = fetched{1,1};
                CurrentData.Lum = CurrentData.Lum*-1;
                set(handles.ShowingText, 'String', get(handles.CurrentDataBox, 'String'));
                %plots data
                hold(handles.NowAxes, 'off');
                plot(handles.NowAxes, CurrentData.Time, CurrentData.Lum, 'Color', 'blue');
                %sends job for file creation
                job = batch(cluster,@CreateFileLum, 1, {QueueInfo(dataset).SegmentSize, QueueInfo(dataset).TotalTime, QueueInfo(dataset).Board, QueueInfo(dataset).ProbeLamp, QueueInfo(dataset).Averages, QueueInfo(dataset).RepRate, QueueInfo(dataset).Filename, QueueInfo(dataset).Comments, QueueInfo(dataset).PulseEnergy, QueueInfo(dataset).Excitation, QueueInfo(dataset).Observation, CurrentData.Time, CurrentData.Lum});
                progress = 2;
            case 2
                %try/catch to determine if job is complete, if yes,
                %proceed, if no, delay until next call
                try
                    fetched = fetchOutputs(job);
                catch err
                    return;
                end
                %retreives file from job
                doc = fetched{1,1};
                %saves file as csv
                dlmcell(QueueInfo(dataset).Filename,doc);
                %plots data on lower axes
                hold(handles.PastAxes, 'on');
                CompletedData(dataset).Time = CurrentData.Time;
                CompletedData(dataset).data = CurrentData.Lum;
                if color > 6
                    color = 0;
                end
                col = cstring(mod(color,6)+1);
                color = color +1;
                if isequal(PlottedDataNames{1,1},'')
                    PlottedDataNames{1,1} = get(handles.CurrentDataBox,'String');
                    PlottedData{1,1} = plot(handles.PastAxes, CompletedData(dataset).Time, CompletedData(dataset).data, 'Color', col);
                else
                    PlottedDataNames{length(PlottedDataNames)+1,1}=get(handles.CurrentDataBox,'String');
                    PlottedData{length(PlottedData)+1,1} = plot(handles.PastAxes, CompletedData(dataset).Time, CompletedData(dataset).data, 'Color', col);
                end
                %renews data tables
                set(handles.AvailableTable, 'data', CompletedNames);
                set(handles.DisplayedTable, 'data', PlottedDataNames);
                clear global CurrentData;
                %if this was the last dataset to be taken, shutters
                %are closed, probe lamp is set to CW and the user
                %is notified that data acquisition has ceased.
                if dataset == length(QueueInfo)
                    PMTcontrol.outputSingleScan(0);
                    Las2Shutter.outputSingleScan(0);
                    Las1Shutter.outputSingleScan(0);
                    ProbeShutter.outputSingleScan(0);
                    fprintf(delayGen, ':pulse2:state 0<cr><lf>');
                    set(handles.CurrentDataBox, 'BackgroundColor', [1 .2 .2]);
                    set(handles.CurrentDataBox, 'String', '');
                end
                %resets parameters for next dataset
                progress = 0;
                complete = 1;
                dataset = dataset+1;
        end
        autoupdate2(hObject,eventdata, handles);
end




% --- Outputs from this function are returned to the command line.
function varargout = ExecuteGui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

function closeGUI(src,evnt, handles)
%called on closing of GUI, clears all global parameters and sits
%instruments to default states
selection = questdlg('Are you sure?','Close','Yes','No','Yes');
switch selection
    case 'Yes'
        selection = questdlg('Would you like to perform another experiment?','set-up?','Yes','No','Yes');
        switch selection
            case 'Yes'
                clear global QueueInfo;
                clear global QueueNames;
                clear global AvailableCellSelect;
                clear global DisplayedCellSelect;
                clear global CompletedData;
                clear global CompletedNames;
                clear global PlottedDataNames;
                clear global PlottedData;
                clear global dataset;
                delete(gcf);
                CsMl_FreeAllSystems();
                TAsetupGUI(1);
            case 'No'
                if isequal(get(handles.ExecuteTimer, 'Running'),'on')
                    stop(handles.ExecuteTimer);
                end
                CsMl_FreeAllSystems();
                clear global Monachromator;
                global delayGen;
                fprintf(delayGen, ':pulse2:state 0<cr><lf>');
                clear global delayGen;
                global PMTcontrol;
                PMTcontrol.outputSingleScan(0);
                clear global PMTcontrol;
                clear global Las1Shutter;
                clear global Las2Shutter;
                clear global ProbeShutter;
                clear global dataset;
                clear global complete;
                clear global progress;
                clear global cluster;
                clear global job;
                clear global CompletedData;
                clear global CompletedNames;
                clear global PlottedDataNames;
                clear global PlottedData;
                clear global QueueInfo;
                clear global QueueNames;
                clear global AvailableCellSelect;
                clear global DisplayedCellSelect;
                clear global color;
                clear global cstring;
                clear global col;
                instrreset
                delete(gcf)
        end
    case 'No'
        return
end


function CurrentDataBox_Callback(hObject, eventdata, handles)
% hObject    handle to CurrentDataBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --- Executes during object creation, after setting all properties.
function CurrentDataBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CurrentDataBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in GoButton.
function GoButton_Callback(hObject, eventdata, handles)
% hObject    handle to GoButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%
%starts timer for data acquisition
if isequal(get(handles.ExecuteTimer, 'Running'),'off')
    set(handles.CurrentDataBox, 'BackgroundColor', [.33 .63 .82]);
    start(handles.ExecuteTimer);
else
    warndlg('Already Running');
end


% --- Executes on button press in StopButton.
function StopButton_Callback(hObject, eventdata, handles)
% hObject    handle to StopButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%
%stops timer for data acquisition
if isequal(get(handles.ExecuteTimer, 'Running'),'on')
    set(handles.CurrentDataBox, 'BackgroundColor', [1 .2 .2]);
    stop(handles.ExecuteTimer);
else
    warndlg('Not Running');
end


% --- Executes on button press in PlotButton.
function PlotButton_Callback(hObject, eventdata, handles)
% hObject    handle to PlotButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global PlottedData;
global PlottedDataNames;
global AvailableCellSelect;
global CompletedData;
global CompletedNames;
global color;
global cstring;
if isempty(AvailableCellSelect);
    warndlg('No selection made');
    return;
end
sizeSelect = size(AvailableCellSelect);
if sizeSelect(1) > 1
    warndlg('only one dataset may be selected');
    return;
end
hold(handles.PastAxes, 'on');
if color > 6
    color = 0;
end
col = cstring(mod(color,6)+1);
color = color +1;
if isequal(PlottedDataNames{1,1}, '')
    PlottedData{1,1} = plot(handles.PastAxes, CompletedData(AvailableCellSelect(1,1)).Time,CompletedData(AvailableCellSelect(1,1)).data, 'Color', col);
    PlottedDataNames{1,1} = CompletedNames{AvailableCellSelect(1,1),1};
else
    PlottedData{length(PlottedData)+1,1} = plot(handles.PastAxes, CompletedData(AvailableCellSelect(1,1)).Time,CompletedData(AvailableCellSelect(1,1)).data, 'Color', col);
    PlottedDataNames{length(PlottedDataNames)+1,1} = CompletedNames{AvailableCellSelect(1,1),1};
end
set(handles.DisplayedTable, 'data', PlottedDataNames);
autoupdate2(hObject,eventdata, handles);

% --- Executes on button press in RemoveButton.
function RemoveButton_Callback(hObject, eventdata, handles)
% hObject    handle to RemoveButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global PlottedData;
global PlottedDataNames;
global DisplayedCellSelect;
if isempty(DisplayedCellSelect);
    warndlg('No selection made');
    return;
end
sizeSelect = size(DisplayedCellSelect);
if sizeSelect(1) > 1
    warndlg('only one dataset may be selected');
    return;
end
delete(PlottedData{DisplayedCellSelect(1,1),1})
PlottedData{DisplayedCellSelect(1,1),1} = '';
PlottedDataNames{DisplayedCellSelect(1,1),1} = '';
if length(PlottedData) ~= 1
    PlottedData = PlottedData(~strcmp(PlottedData,PlottedData{DisplayedCellSelect(1,1),1}));
end
if length(PlottedDataNames) ~= 1
    PlottedDataNames = PlottedDataNames(~strcmp(PlottedDataNames,PlottedDataNames{DisplayedCellSelect(1,1),1}));
end
set(handles.DisplayedTable, 'data', PlottedDataNames);
autoupdate2(hObject,eventdata, handles);


% --- Executes on button press in AutoAxes.
function AutoAxes_Callback(hObject, eventdata, handles)
% hObject    handle to AutoAxes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if get(handles.NowRadio, 'Value') ==1
    if get(hObject, 'Value') == 1
        axis(handles.NowAxes, 'auto')
    else
        axis(handles.NowAxes, 'manual')
    end
else
    if get(hObject, 'Value') == 1
        axis(handles.PastAxes, 'auto')
    else
        axis(handles.PastAxes, 'manual')
    end
end
autoupdate2(hObject,eventdata, handles);
% Hint: get(hObject,'Value') returns toggle state of AutoAxes



function XlowBox_Callback(hObject, eventdata, handles)
% hObject    handle to XlowBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
new = str2double(get(hObject, 'String'));
opposite = get(handles.XhighBox, 'String');
oppositenum = str2double(opposite);
while (new > oppositenum) || isnan(new)
    new = str2double(inputdlg(strcat('invalid bounds, enter value less than ', opposite,')')));
    if isempty(new)
        return;
    end
end
if get(handles.PastRadio, 'Value') == 1
    xlim(handles.PastAxes, [new,oppositenum]);
else
    xlim(handles.NowAxes, [new,oppositenum]);
end
set(handles.AutoAxes, 'Value', 0);
autoupdate2(hObject,eventdata, handles);



% --- Executes during object creation, after setting all properties.
function XlowBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to XlowBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function YlowBox_Callback(hObject, eventdata, handles)
% hObject    handle to YlowBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
new = str2double(get(hObject, 'String'));
opposite = get(handles.YhighBox, 'String');
oppositenum = str2double(opposite);
while (new > oppositenum) || isnan(new)
    new = str2double(inputdlg(strcat('invalid bounds, enter value less than ', opposite,')')));
    if isempty(new)
        return;
    end
end
if get(handles.PastRadio, 'Value') == 1
    ylim(handles.PastAxes, [new,oppositenum]);
else
    ylim(handles.NowAxes, [new,oppositenum]);
end
set(handles.AutoAxes, 'Value', 0);
autoupdate2(hObject,eventdata, handles);


% --- Executes during object creation, after setting all properties.
function YlowBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to YlowBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function XhighBox_Callback(hObject, eventdata, handles)
% hObject    handle to XhighBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
new = str2double(get(hObject, 'String'))
opposite = get(handles.XlowBox, 'String');
oppositenum = str2double(opposite)
while (new < oppositenum) || isnan(new)
    new = str2double(inputdlg(strcat('invalid bounds, enter value greater than ', opposite,')')));
    if isempty(new)
        return;
    end
end
if get(handles.PastRadio, 'Value') == 1
    xlim(handles.PastAxes, [oppositenum,new]);
else
    xlim(handles.NowAxes, [oppositenum,new]);
end
set(handles.AutoAxes, 'Value', 0);
autoupdate2(hObject,eventdata, handles);


% --- Executes during object creation, after setting all properties.
function XhighBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to XhighBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function YhighBox_Callback(hObject, eventdata, handles)
% hObject    handle to YhighBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
new = str2double(get(hObject, 'String'));
opposite = get(handles.YlowBox, 'String');
oppositenum = str2double(opposite);
while (new < oppositenum) || isnan(new)
    new = str2double(inputdlg(strcat('invalid bounds, enter value greater than ', opposite,')')));
    if isempty(new)
        return;
    end
end
if get(handles.PastRadio, 'Value') == 1
    ylim(handles.PastAxes, [oppositenum,new]);
else
    ylim(handles.NowAxes, [oppositenum,new]);
end
set(handles.AutoAxes, 'Value', 0);


% --- Executes during object creation, after setting all properties.
function YhighBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to YhighBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in NowRadio.
function NowRadio_Callback(hObject, eventdata, handles)
% hObject    handle to NowRadio (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(hObject, 'Value', 1);
set(handles.PastRadio, 'Value', 0);
if isequal(get(handles.NowAxes, 'XLimMode'),'manual')||isequal(get(handles.NowAxes, 'YLimMode'),'manual')
    set(handles.AutoAxes, 'Value', 0);
else
    set(handles.AutoAxes, 'Value', 1);
end
autoupdate2(hObject,eventdata, handles);


% --- Executes on button press in PastRadio.
function PastRadio_Callback(hObject, eventdata, handles)
% hObject    handle to PastRadio (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(hObject, 'Value', 1);
set(handles.NowRadio, 'Value', 0);
if isequal(get(handles.PastAxes, 'XLimMode'),'manual')||isequal(get(handles.PastAxes, 'YLimMode'),'manual')
    set(handles.AutoAxes, 'Value', 0);
else
    set(handles.AutoAxes, 'Value', 1);
end
autoupdate2(hObject,eventdata, handles);


function autoupdate2(hObject,eventdata, handles)
%updates axes parameter display
if get(handles.PastRadio, 'Value') ==1
    xLimits = get(handles.PastAxes, 'Xlim');
    yLimits = get(handles.PastAxes, 'YLim');
else
    xLimits = get(handles.NowAxes, 'Xlim');
    yLimits = get(handles.NowAxes, 'YLim');
end
set(handles.YlowBox, 'String', yLimits(1,1));
set(handles.YhighBox, 'String', yLimits(1,2));
set(handles.XlowBox, 'String', xLimits(1,1));
set(handles.XhighBox, 'String', xLimits(1,2));
