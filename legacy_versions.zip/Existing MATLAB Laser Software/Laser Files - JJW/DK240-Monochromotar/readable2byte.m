function [ hibyte, lowbyte ] = readable2byte( readable )
%converts a readable number to its hibyte and lowbyte values
lowbyte = rem(readable, 256);
hibyte = floor(readable/256);
end

