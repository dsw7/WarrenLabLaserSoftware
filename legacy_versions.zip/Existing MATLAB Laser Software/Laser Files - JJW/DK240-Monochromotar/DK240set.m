function [Accepted] = DK240set( device, setting, setTo )
%DK240set sets instrument properties for the DK240 monochromator
%
%   input
%    device = object representing monochromator
%    setting = setting to be changed, options are:
%       'Position'  - sets the wavelength
%       'Units'     - sets the Units
%       (00=microns,01=nanometers,02=angstroms)
%
%    setTo = value to set setting to
%
%   output
%    Accepted = returns 1 if setting changed, 0 if not.
%    
Answer = 0;
if isequal(setting, 'Position')
    byte = 16;
    [hibyte lowbyte] = readable2byte(setTo);
    Answer = 1;
end
if isequal(setting, 'Units')
    byte = 50;
    Answer = 2;
end
if Answer == 1;
    fwrite(device, [byte hibyte lowbyte]);
    pause(.4);
    response = fread(device, device.BytesAvailable);
end
if Answer == 2;
    fwrite(device, [byte setTo])
    pause(.4);
    response = fread(device, device.BytesAvailable);
end
if response(1) >128 || Answer ==0
    Accepted = 0;
else
    Accepted = 1;
end

end

