function [ CM112 ] = OpenCM112Link( loc )
%OpenCM112Link opens communication with the CM112 Monochromator
%  input
%   loc = location of monochromator (i.e. 'COM3')
%  output
%   CM112 = device for use
%  
%  If location is input, function searches location for monochromator, if
%  no location is input, function searches all available serial ports for
%  monochromator.

%handles input argument
if nargin == 1
    %connecting
    CM112 = serial(loc);
    try
        %opening communication
        fopen(CM112);
        %Executing monochromotar echo command
        fwrite(CM112, 27);
        %pausing to allow monochromator to process
        pause(.2)
        %retreiving echo
        response = fread(CM112, CM112.BytesAvailable);
    catch
        %if an error occured, connections are closed
        fclose(CM112);
        clear CM112;
        CM112 = 'device not found';
    end
%handles no input situation
else
    %serial locations to check
    COM ={'COM1','COM2','COM3','COM4','COM5','COM6','COM7','COM8'};
    %value for looping
    i = 1;
    %boolean for connection made
    linked = 0;
    %while loop executes while link has not been made and all ports have
    %not been checked
    while (linked == 0)&&(i<=length(COM))
        %boolean for location possible
        available = 1;
        try
            %retreiving location to check from array
            location = COM{i};
            %Connection being made
            CM112 = serial(location);
            %Opening communication
            fopen(CM112);
            %executing echo to monochromotar
            fwrite(CM112, 27);
            %pausing to allow instrument to respond
            pause(.2);
            %retreiving echo
            response = fread(CM112, CM112.BytesAvailable);
        catch
            %closing connection if monochromotar not present
            try
                fclose(CM112);
                clear CM112;
            catch
            end
            CM112 = 'device not found';
            available = 0;
        end
        %opening connection if device detected
        if available == 1;
            fwrite(CM112, 27);
            pause(.2)
            response = fread(CM112, CM112.BytesAvailable);
            %signifying link
            if response == 27
                linked = 1;
            else
                CM112 = 'device not found';
            end
        end
        i = i+1;
    end
end

