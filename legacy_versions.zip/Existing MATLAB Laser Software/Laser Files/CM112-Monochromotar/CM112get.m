function [ Answer ] = CM112get( device, query )
%CM112get returns requested information about the monochromator
%   input
%    device = object for the monochromator
%    query = requesed info
%
%    info that can be requested 
%               - OUTPUT
%   'Position'  - wavelength
%   'Grooves'   - Grooves per mm on grating
%   'Blaze'     - not sure what this is
%   'Grating#'  - Current Grating Number
%   'Speed'     - Current Scan Speed
%   'Gratings'  - Number of Gratings
%   'Units'     - wavelength units (0=microns, 1=nanometers, 2=angstroms)
%   'Serial'    - Serial Number
%
%   output
%    Answer = OUTPUT
Answer = 'Invalid input argument';
if isequal(query, 'Position')
    byte = 00;
    Answer = 1;
end
if isequal(query, 'Grooves')
    byte = 02;
    Answer = 1;
end
if isequal(query, 'Blaze')
    byte = 03;
    Answer = 1;
end
if isequal(query, 'Grating#')
    byte = 04;
    Answer = 1;
end
if isequal(query, 'Speed')
    byte = 05;
    Answer = 1;
end
if isequal(query, 'Gratings')
    byte = 13;
    Answer = 1;
end
if isequal(query, 'Units')
    byte = 14;
    Answer = 1;
end
if isequal(query, 'Serial')
    byte = 19;
    Answer = 1;
end
if Answer == 1
    fwrite(device, [56 byte])
    pause(.2);
    response = fread(device, device.BytesAvailable);
    Answer = byte2readable(response(1), response(2));
end
end

